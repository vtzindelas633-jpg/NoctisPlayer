package com.noctis.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@OptIn(markerClass = UnstableApi.class)
public class NativePlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private DefaultTrackSelector trackSelector;
    private PlayerView playerView;
    private RelativeLayout controlsOverlay;
    private ProgressBar loadingSpinner;
    private TextView tvTitle, tvSubtitle, tvPosition, tvDuration, tvGestureHud;
    private SeekBar seekBar;
    private Button btnPlay, btnLock, btnUnlock, btnSpeed, btnResize, btnNext;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean controlsVisible = true, screenLocked = false, userScrubbing = false, nextRequested = false, gestureActive = false;
    private int resizeModeIndex = 0, initialVolume = 0;
    private float currentSpeed = 1.0f, touchStartX = 0f, touchStartY = 0f, initialBrightness = 0.7f;
    private AudioManager audioManager;

    private final Runnable hideControlsRunnable = () -> { if (!screenLocked && player != null && player.isPlaying()) { controlsVisible = false; controlsOverlay.setVisibility(View.GONE); } };
    private final Runnable progressUpdater = new Runnable() {
        @Override public void run() {
            if (player != null && !userScrubbing) {
                long pos = player.getCurrentPosition(), dur = Math.max(0L, player.getDuration());
                tvPosition.setText(formatTime(pos)); tvDuration.setText(formatTime(dur));
                if (dur > 0) { seekBar.setMax((int) dur); seekBar.setProgress((int) pos); }
            }
            uiHandler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_player);
        enterImmersiveMode();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        playerView = findViewById(R.id.exo_player_view);
        controlsOverlay = findViewById(R.id.native_controls_overlay);
        loadingSpinner = findViewById(R.id.native_loading_spinner);
        tvTitle = findViewById(R.id.tv_native_title); tvSubtitle = findViewById(R.id.tv_native_subtitle);
        tvPosition = findViewById(R.id.tv_native_position); tvDuration = findViewById(R.id.tv_native_duration);
        tvGestureHud = findViewById(R.id.native_gesture_hud); seekBar = findViewById(R.id.native_seekbar);
        btnPlay = findViewById(R.id.btn_native_play); btnLock = findViewById(R.id.btn_native_lock);
        btnUnlock = findViewById(R.id.btn_native_unlock); btnSpeed = findViewById(R.id.btn_native_speed);
        btnResize = findViewById(R.id.btn_native_resize); btnNext = findViewById(R.id.btn_native_next);

        Intent i = getIntent();
        currentSpeed = i.getFloatExtra("playbackSpeed", 1.0f);
        tvTitle.setText(i.getStringExtra("title") != null ? i.getStringExtra("title") : "Noctis");
        String sub = i.getStringExtra("subtitle");
        tvSubtitle.setText(sub != null && !sub.isEmpty() ? sub : "Media3 ExoPlayer • MKV");
        btnSpeed.setText(String.format(Locale.US, "%.2gx", currentSpeed));
        btnNext.setVisibility(i.getBooleanExtra("hasNextEpisode", false) ? View.VISIBLE : View.GONE);

        initExoPlayer(i.getStringExtra("uri"), i.getStringExtra("subtitleUri"), i.getLongExtra("startPositionMs", 0L), i.getStringExtra("preferredAudio"), i.getStringExtra("preferredSubtitle"));
        bindControls();
    }

    private void initExoPlayer(String uriStr, String subUri, long startPosMs, String prefAudio, String prefSub) {
        trackSelector = new DefaultTrackSelector(this);
        DefaultTrackSelector.Parameters.Builder pb = trackSelector.buildUponParameters();
        if (prefAudio != null && !prefAudio.isEmpty()) pb.setPreferredAudioLanguage(prefAudio);
        if (prefSub != null && !"off".equals(prefSub)) pb.setPreferredTextLanguage(prefSub);
        else pb.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
        trackSelector.setParameters(pb);

        DefaultRenderersFactory rf = new DefaultRenderersFactory(this).setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);
        player = new ExoPlayer.Builder(this, rf).setTrackSelector(trackSelector).build();
        playerView.setPlayer(player);

        MediaItem.Builder mb = new MediaItem.Builder().setUri(Uri.parse(uriStr));
        if (subUri != null && !subUri.isEmpty()) {
            String mime = subUri.toLowerCase(Locale.ROOT).endsWith(".vtt") ? MimeTypes.TEXT_VTT : MimeTypes.APPLICATION_SUBRIP;
            mb.setSubtitleConfigurations(Collections.singletonList(new MediaItem.SubtitleConfiguration.Builder(Uri.parse(subUri)).setMimeType(mime).setLanguage("pt").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()));
        }
        player.setMediaItem(mb.build());
        player.setPlaybackParameters(new PlaybackParameters(currentSpeed));
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int s) { loadingSpinner.setVisibility(s == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE); if (s == Player.STATE_ENDED) finishWithResult(true); }
            @Override public void onIsPlayingChanged(boolean p) { btnPlay.setText(p ? "❚❚" : "▶"); if (p) scheduleAutoHide(); }
            @Override public void onPlayerError(@NonNull PlaybackException e) {
                loadingSpinner.setVisibility(View.GONE);
                new AlertDialog.Builder(NativePlayerActivity.this).setTitle("Codec incompatível").setMessage("Não foi possível decodificar esta mídia: " + e.getErrorCodeName()).setPositiveButton("Fechar", (d, w) -> finishWithResult(false)).show();
            }
        });
        player.prepare();
        if (startPosMs > 2000L) player.seekTo(startPosMs);
        player.setPlayWhenReady(true);
        uiHandler.post(progressUpdater);
        scheduleAutoHide();
    }

    private void bindControls() {
        findViewById(R.id.btn_native_back).setOnClickListener(v -> finishWithResult(false));
        btnPlay.setOnClickListener(v -> { if (player.isPlaying()) player.pause(); else player.play(); scheduleAutoHide(); });
        findViewById(R.id.btn_native_rew).setOnClickListener(v -> { player.seekTo(Math.max(0L, player.getCurrentPosition() - 10_000L)); scheduleAutoHide(); });
        findViewById(R.id.btn_native_fwd).setOnClickListener(v -> { long d = Math.max(0L, player.getDuration()); player.seekTo(Math.min(d > 0 ? d : player.getCurrentPosition() + 10_000L, player.getCurrentPosition() + 10_000L)); scheduleAutoHide(); });
        btnLock.setOnClickListener(v -> { screenLocked = true; controlsOverlay.setVisibility(View.GONE); btnUnlock.setVisibility(View.VISIBLE); });
        btnUnlock.setOnClickListener(v -> { screenLocked = false; btnUnlock.setVisibility(View.GONE); showControls(); });
        findViewById(R.id.btn_native_audio).setOnClickListener(v -> showTrackDialog(C.TRACK_TYPE_AUDIO, "Faixas de Áudio"));
        findViewById(R.id.btn_native_subtitles).setOnClickListener(v -> showTrackDialog(C.TRACK_TYPE_TEXT, "Legendas"));
        btnSpeed.setOnClickListener(v -> showSpeedDialog());
        btnResize.setOnClickListener(v -> {
            int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL};
            resizeModeIndex = (resizeModeIndex + 1) % modes.length;
            playerView.setResizeMode(modes[resizeModeIndex]);
            scheduleAutoHide();
        });
        btnNext.setOnClickListener(v -> { nextRequested = true; finishWithResult(true); });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { if (u) tvPosition.setText(formatTime(p)); }
            @Override public void onStartTrackingTouch(SeekBar sb) { userScrubbing = true; uiHandler.removeCallbacks(hideControlsRunnable); }
            @Override public void onStopTrackingTouch(SeekBar sb) { userScrubbing = false; player.seekTo(sb.getProgress()); scheduleAutoHide(); }
        });
        findViewById(R.id.native_player_root).setOnTouchListener((v, ev) -> handleTouch(ev));
    }

    private boolean handleTouch(MotionEvent ev) {
        if (screenLocked) { if (ev.getAction() == MotionEvent.ACTION_UP) btnUnlock.setVisibility(View.VISIBLE); return true; }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = ev.getX(); touchStartY = ev.getY(); gestureActive = false;
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                initialBrightness = lp.screenBrightness < 0 ? 0.6f : lp.screenBrightness;
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                return true;
            case MotionEvent.ACTION_MOVE:
                float dy = touchStartY - ev.getY();
                if (Math.abs(dy) > 36) {
                    gestureActive = true;
                    float ratio = dy / Math.max(300f, playerView.getHeight());
                    if (touchStartX < playerView.getWidth() / 2f) {
                        float nb = Math.max(0.05f, Math.min(1.0f, initialBrightness + ratio));
                        WindowManager.LayoutParams p = getWindow().getAttributes(); p.screenBrightness = nb; getWindow().setAttributes(p);
                        tvGestureHud.setText("Brilho: " + Math.round(nb * 100) + "%"); tvGestureHud.setVisibility(View.VISIBLE);
                    } else {
                        int maxV = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int nv = Math.max(0, Math.min(maxV, initialVolume + Math.round(ratio * maxV)));
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0);
                        tvGestureHud.setText("Volume: " + Math.round((nv * 100f) / Math.max(1, maxV)) + "%"); tvGestureHud.setVisibility(View.VISIBLE);
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
                tvGestureHud.setVisibility(View.GONE);
                if (!gestureActive) { if (controlsVisible) { controlsVisible = false; controlsOverlay.setVisibility(View.GONE); } else showControls(); }
                return true;
        }
        return false;
    }

    private void showTrackDialog(int type, String title) {
        if (player == null) return;
        List<String> labels = new ArrayList<>(); List<TrackSelectionOverride> ov = new ArrayList<>();
        if (type == C.TRACK_TYPE_TEXT) { labels.add("Desativar legendas"); ov.add(null); }
        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != type) continue;
            TrackGroup mg = g.getMediaTrackGroup();
            for (int i = 0; i < mg.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                Format f = mg.getFormat(i);
                String lang = f.language != null ? f.language.toUpperCase(Locale.ROOT) : "UND";
                labels.add(f.label != null ? f.label : (type == C.TRACK_TYPE_AUDIO ? "Áudio " + lang : "Legenda " + lang));
                ov.add(new TrackSelectionOverride(mg, Collections.singletonList(i)));
            }
        }
        if (labels.isEmpty()) { Toast.makeText(this, "Sem faixas adicionais.", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle(title).setItems(labels.toArray(new String[0]), (d, w) -> {
            DefaultTrackSelector.Parameters.Builder b = trackSelector.buildUponParameters();
            if (type == C.TRACK_TYPE_TEXT && w == 0) b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
            else { b.setTrackTypeDisabled(type, false); b.setOverrideForType(ov.get(w)); }
            trackSelector.setParameters(b);
        }).show();
    }

    private void showSpeedDialog() {
        final float[] sp = {0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};
        final String[] lb = {"0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"};
        new AlertDialog.Builder(this).setTitle("Velocidade").setItems(lb, (d, w) -> { currentSpeed = sp[w]; player.setPlaybackParameters(new PlaybackParameters(currentSpeed)); btnSpeed.setText(lb[w]); }).show();
    }

    private void showControls() { controlsVisible = true; controlsOverlay.setVisibility(View.VISIBLE); scheduleAutoHide(); }
    private void scheduleAutoHide() { uiHandler.removeCallbacks(hideControlsRunnable); uiHandler.postDelayed(hideControlsRunnable, 3500); }
    private void enterImmersiveMode() { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
    private void finishWithResult(boolean completed) {
        Intent d = new Intent();
        if (player != null) { d.putExtra("positionMs", player.getCurrentPosition()); d.putExtra("durationMs", Math.max(0L, player.getDuration())); }
        d.putExtra("completed", completed); d.putExtra("nextRequested", nextRequested);
        setResult(RESULT_OK, d); finish();
    }
    @Override public void onBackPressed() { finishWithResult(false); }
    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { super.onDestroy(); uiHandler.removeCallbacksAndMessages(null); if (player != null) { player.release(); player = null; } }
    private String formatTime(long ms) { if (ms <= 0) return "00:00"; long s = ms/1000, h = s/3600, m = (s%3600)/60, r = s%60; return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, r) : String.format(Locale.US, "%02d:%02d", m, r); }
}
