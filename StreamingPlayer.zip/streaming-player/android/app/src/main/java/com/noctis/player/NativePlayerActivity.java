package com.noctis.player;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@OptIn(markerClass = UnstableApi.class)
public class NativePlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private DefaultTrackSelector trackSelector;
    private PlayerView playerView;
    private RelativeLayout controlsOverlay;
    private ProgressBar loadingSpinner;
    private TextView tvTitle, tvSubtitle, tvPosition, tvDuration, tvGestureHud, tvSpeedLabel, tvResizeLabel;
    private SeekBar seekBar;
    private ImageButton btnPlay;
    private View btnLock, btnUnlock, btnSpeed, btnResize, btnRotate, btnNext;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean controlsVisible = true;
    private boolean screenLocked = false;
    private boolean userScrubbing = false;
    private boolean nextRequested = false;
    private boolean gestureActive = false;
    private boolean isPortrait = false;
    private int resizeModeIndex = 0;
    private int initialVolume = 0;
    private float currentSpeed = 1.0f;
    private float touchStartX = 0f, touchStartY = 0f, initialBrightness = 0.7f;
    private long lastTapTime = 0L;
    private String currentVideoUri = "";
    private AudioManager audioManager;

    private final ActivityResultLauncher<String[]> subtitlePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null && player != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {
                    }
                    attachExternalSubtitle(uri.toString());
                }
            });

    private final Runnable hideControlsRunnable = () -> {
        if (!screenLocked && player != null && player.isPlaying()) {
            controlsVisible = false;
            controlsOverlay.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                if (!controlsVisible) controlsOverlay.setVisibility(View.GONE);
            }).start();
        }
    };

    private final Runnable hideHudRunnable = () -> tvGestureHud.setVisibility(View.GONE);

    private final Runnable progressUpdater = new Runnable() {
        @Override
        public void run() {
            if (player != null && !userScrubbing) {
                long pos = player.getCurrentPosition();
                long dur = Math.max(0L, player.getDuration());
                long buf = Math.max(0L, player.getBufferedPosition());
                tvPosition.setText(formatTime(pos));
                tvDuration.setText(formatTime(dur));
                if (dur > 0) {
                    seekBar.setMax((int) dur);
                    seekBar.setProgress((int) pos);
                    seekBar.setSecondaryProgress((int) Math.min(dur, buf));
                }
            }
            uiHandler.postDelayed(this, 400);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_player);
        enterImmersiveMode();

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        playerView = findViewById(R.id.exo_player_view);
        controlsOverlay = findViewById(R.id.native_controls_overlay);
        loadingSpinner = findViewById(R.id.native_loading_spinner);
        tvTitle = findViewById(R.id.tv_native_title);
        tvSubtitle = findViewById(R.id.tv_native_subtitle);
        tvPosition = findViewById(R.id.tv_native_position);
        tvDuration = findViewById(R.id.tv_native_duration);
        tvGestureHud = findViewById(R.id.native_gesture_hud);
        tvSpeedLabel = findViewById(R.id.tv_native_speed_label);
        tvResizeLabel = findViewById(R.id.tv_native_resize_label);
        seekBar = findViewById(R.id.native_seekbar);
        btnPlay = findViewById(R.id.btn_native_play);
        btnLock = findViewById(R.id.btn_native_lock);
        btnUnlock = findViewById(R.id.btn_native_unlock);
        btnSpeed = findViewById(R.id.btn_native_speed);
        btnResize = findViewById(R.id.btn_native_resize);
        btnRotate = findViewById(R.id.btn_native_rotate);
        btnNext = findViewById(R.id.btn_native_next);

        Intent i = getIntent();
        currentVideoUri = i.getStringExtra("uri") != null ? i.getStringExtra("uri") : "";
        currentSpeed = i.getFloatExtra("playbackSpeed", 1.0f);
        String title = i.getStringExtra("title");
        String sub = i.getStringExtra("subtitle");

        tvTitle.setText(title != null && !title.isEmpty() ? title : "Noctis Player");
        tvSubtitle.setText(sub != null && !sub.isEmpty() ? sub : "Media3 ExoPlayer • MKV");
        tvSpeedLabel.setText(formatSpeed(currentSpeed));
        btnNext.setVisibility(i.getBooleanExtra("hasNextEpisode", false) ? View.VISIBLE : View.GONE);

        initExoPlayer(
                currentVideoUri,
                i.getStringExtra("subtitleUri"),
                i.getLongExtra("startPositionMs", 0L),
                i.getStringExtra("preferredAudio"),
                i.getStringExtra("preferredSubtitle")
        );
        bindControls();
    }

    private void initExoPlayer(String uriStr, String subUri, long startPosMs, String prefAudio, String prefSub) {
        trackSelector = new DefaultTrackSelector(this);
        DefaultTrackSelector.Parameters.Builder pb = trackSelector.buildUponParameters();
        if (prefAudio != null && !prefAudio.isEmpty()) pb.setPreferredAudioLanguage(prefAudio);
        if (prefSub != null && !"off".equals(prefSub)) pb.setPreferredTextLanguage(prefSub);
        else pb.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
        trackSelector.setParameters(pb);

        DefaultRenderersFactory rf = new DefaultRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);
        player = new ExoPlayer.Builder(this, rf).setTrackSelector(trackSelector).build();
        playerView.setPlayer(player);

        player.setMediaItem(buildMediaItem(uriStr, subUri));
        player.setPlaybackParameters(new PlaybackParameters(currentSpeed));
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int s) {
                loadingSpinner.setVisibility(s == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                if (s == Player.STATE_ENDED) finishWithResult(true);
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                btnPlay.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play);
                if (isPlaying) scheduleAutoHide();
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException e) {
                loadingSpinner.setVisibility(View.GONE);
                new AlertDialog.Builder(NativePlayerActivity.this, R.style.NoctisDialogTheme)
                        .setTitle("Codec ou formato incompatível")
                        .setMessage("Não foi possível decodificar esta mídia com os codecs disponíveis.\n\nCódigo: " + e.getErrorCodeName())
                        .setPositiveButton("Fechar", (d, w) -> finishWithResult(false))
                        .show();
            }
        });

        player.prepare();
        if (startPosMs > 2000L) player.seekTo(startPosMs);
        player.setPlayWhenReady(true);
        uiHandler.post(progressUpdater);
        scheduleAutoHide();
    }

    private MediaItem buildMediaItem(String uriStr, String subUri) {
        MediaItem.Builder mb = new MediaItem.Builder().setUri(Uri.parse(uriStr));
        if (subUri != null && !subUri.isEmpty()) {
            String lower = subUri.toLowerCase(Locale.ROOT);
            String mime = lower.endsWith(".vtt") ? MimeTypes.TEXT_VTT
                    : (lower.endsWith(".ass") || lower.endsWith(".ssa")) ? MimeTypes.TEXT_SSA
                    : MimeTypes.APPLICATION_SUBRIP;
            MediaItem.SubtitleConfiguration sc = new MediaItem.SubtitleConfiguration.Builder(Uri.parse(subUri))
                    .setMimeType(mime)
                    .setLanguage("pt")
                    .setLabel("Legenda Externa")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build();
            mb.setSubtitleConfigurations(Collections.singletonList(sc));
        }
        return mb.build();
    }

    private void attachExternalSubtitle(String subUri) {
        if (player == null || currentVideoUri.isEmpty()) return;
        long pos = player.getCurrentPosition();
        boolean wasPlaying = player.isPlaying();
        DefaultTrackSelector.Parameters.Builder b = trackSelector.buildUponParameters();
        b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
        trackSelector.setParameters(b);

        player.setMediaItem(buildMediaItem(currentVideoUri, subUri));
        player.prepare();
        player.seekTo(pos);
        player.setPlayWhenReady(wasPlaying);
        showTransientHud("Legenda externa carregada");
    }

    private void bindControls() {
        findViewById(R.id.btn_native_back).setOnClickListener(v -> finishWithResult(false));

        btnPlay.setOnClickListener(v -> {
            if (player.isPlaying()) player.pause();
            else player.play();
            scheduleAutoHide();
        });

        findViewById(R.id.btn_native_rew).setOnClickListener(v -> seekBy(-10_000L));
        findViewById(R.id.btn_native_fwd).setOnClickListener(v -> seekBy(10_000L));

        btnLock.setOnClickListener(v -> {
            screenLocked = true;
            controlsVisible = false;
            controlsOverlay.setVisibility(View.GONE);
            btnUnlock.setVisibility(View.VISIBLE);
        });

        btnUnlock.setOnClickListener(v -> {
            screenLocked = false;
            btnUnlock.setVisibility(View.GONE);
            showControls();
        });

        findViewById(R.id.btn_native_audio).setOnClickListener(v -> showTrackDialog(C.TRACK_TYPE_AUDIO, "Faixas de Áudio"));
        findViewById(R.id.btn_native_subtitles).setOnClickListener(v -> showTrackDialog(C.TRACK_TYPE_TEXT, "Legendas"));
        btnSpeed.setOnClickListener(v -> showSpeedDialog());

        btnResize.setOnClickListener(v -> {
            int[] modes = {
                    AspectRatioFrameLayout.RESIZE_MODE_FIT,
                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                    AspectRatioFrameLayout.RESIZE_MODE_FILL
            };
            String[] labels = {"Ajustar", "Zoom", "Preencher"};
            resizeModeIndex = (resizeModeIndex + 1) % modes.length;
            playerView.setResizeMode(modes[resizeModeIndex]);
            tvResizeLabel.setText(labels[resizeModeIndex]);
            showTransientHud("Tela: " + labels[resizeModeIndex]);
            scheduleAutoHide();
        });

        btnRotate.setOnClickListener(v -> {
            isPortrait = !isPortrait;
            setRequestedOrientation(isPortrait
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            scheduleAutoHide();
        });

        btnNext.setOnClickListener(v -> {
            nextRequested = true;
            finishWithResult(true);
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser) tvPosition.setText(formatTime(p));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
                userScrubbing = true;
                uiHandler.removeCallbacks(hideControlsRunnable);
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                userScrubbing = false;
                player.seekTo(sb.getProgress());
                scheduleAutoHide();
            }
        });

        findViewById(R.id.native_player_root).setOnTouchListener((v, ev) -> handleTouch(ev));
    }

    private void seekBy(long deltaMs) {
        if (player == null) return;
        long dur = Math.max(0L, player.getDuration());
        long next = Math.max(0L, player.getCurrentPosition() + deltaMs);
        if (dur > 0) next = Math.min(dur, next);
        player.seekTo(next);
        showTransientHud(deltaMs < 0 ? "-10s" : "+10s");
        scheduleAutoHide();
    }

    private boolean handleTouch(MotionEvent ev) {
        if (screenLocked) {
            if (ev.getAction() == MotionEvent.ACTION_UP) btnUnlock.setVisibility(View.VISIBLE);
            return true;
        }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = ev.getX();
                touchStartY = ev.getY();
                gestureActive = false;
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                initialBrightness = lp.screenBrightness < 0 ? 0.6f : lp.screenBrightness;
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                return true;

            case MotionEvent.ACTION_MOVE:
                float dy = touchStartY - ev.getY();
                if (Math.abs(dy) > 36) {
                    gestureActive = true;
                    float ratio = dy / Math.max(300f, playerView.getHeight());
                    if (touchStartX < playerView.getWidth() / 2f) {
                        float nb = Math.max(0.05f, Math.min(1.0f, initialBrightness + ratio));
                        WindowManager.LayoutParams p = getWindow().getAttributes();
                        p.screenBrightness = nb;
                        getWindow().setAttributes(p);
                        showHud("Brilho  " + Math.round(nb * 100) + "%");
                    } else {
                        int maxV = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int nv = Math.max(0, Math.min(maxV, initialVolume + Math.round(ratio * maxV)));
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0);
                        showHud("Volume  " + Math.round((nv * 100f) / Math.max(1, maxV)) + "%");
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (gestureActive) {
                    uiHandler.postDelayed(hideHudRunnable, 450);
                } else {
                    long now = System.currentTimeMillis();
                    if (now - lastTapTime < 280) {
                        seekBy(ev.getX() < playerView.getWidth() / 2f ? -10_000L : 10_000L);
                    } else {
                        if (controlsVisible) {
                            controlsVisible = false;
                            controlsOverlay.animate().alpha(0f).setDuration(180).withEndAction(() -> {
                                if (!controlsVisible) controlsOverlay.setVisibility(View.GONE);
                            }).start();
                        } else {
                            showControls();
                        }
                    }
                    lastTapTime = now;
                }
                return true;
        }
        return false;
    }

    private void showHud(String text) {
        uiHandler.removeCallbacks(hideHudRunnable);
        tvGestureHud.setText(text);
        tvGestureHud.setVisibility(View.VISIBLE);
    }

    private void showTransientHud(String text) {
        showHud(text);
        uiHandler.postDelayed(hideHudRunnable, 950);
    }

    private void showTrackDialog(int type, String title) {
        if (player == null) return;
        uiHandler.removeCallbacks(hideControlsRunnable);

        List<String> labels = new ArrayList<>();
        List<TrackSelectionOverride> overrides = new ArrayList<>();

        if (type == C.TRACK_TYPE_TEXT) {
            labels.add("Desativar legendas");
            overrides.add(null);
            labels.add("Carregar legenda externa (.SRT / .VTT)");
            overrides.add(null);
        }

        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != type) continue;
            TrackGroup mg = g.getMediaTrackGroup();
            for (int i = 0; i < mg.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                Format f = mg.getFormat(i);
                String lang = f.language != null ? f.language.toUpperCase(Locale.ROOT) : "UND";
                String lbl = f.label != null ? f.label : (type == C.TRACK_TYPE_AUDIO ? "Áudio " + lang : "Legenda " + lang);
                if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) {
                    lbl += " (" + f.channelCount + "ch)";
                }
                labels.add(lbl);
                overrides.add(new TrackSelectionOverride(mg, Collections.singletonList(i)));
            }
        }

        if (labels.isEmpty()) {
            showTransientHud("Nenhuma faixa adicional detectada");
            return;
        }

        new AlertDialog.Builder(this, R.style.NoctisDialogTheme)
                .setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (type == C.TRACK_TYPE_TEXT && which == 1) {
                        subtitlePickerLauncher.launch(new String[]{"*/*"});
                        return;
                    }
                    DefaultTrackSelector.Parameters.Builder b = trackSelector.buildUponParameters();
                    if (type == C.TRACK_TYPE_TEXT && which == 0) {
                        b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
                        showTransientHud("Legendas desativadas");
                    } else {
                        b.setTrackTypeDisabled(type, false);
                        b.setOverrideForType(overrides.get(which));
                        showTransientHud(labels.get(which));
                    }
                    trackSelector.setParameters(b);
                    scheduleAutoHide();
                })
                .setOnCancelListener(d -> scheduleAutoHide())
                .show();
    }

    private void showSpeedDialog() {
        uiHandler.removeCallbacks(hideControlsRunnable);
        final float[] speeds = {0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};
        final String[] labels = {"0.5x", "0.75x", "1.0x (Normal)", "1.25x", "1.5x", "1.75x", "2.0x"};
        new AlertDialog.Builder(this, R.style.NoctisDialogTheme)
                .setTitle("Velocidade de Reprodução")
                .setItems(labels, (d, which) -> {
                    currentSpeed = speeds[which];
                    player.setPlaybackParameters(new PlaybackParameters(currentSpeed));
                    tvSpeedLabel.setText(formatSpeed(currentSpeed));
                    showTransientHud("Velocidade: " + formatSpeed(currentSpeed));
                    scheduleAutoHide();
                })
                .setOnCancelListener(d -> scheduleAutoHide())
                .show();
    }

    private void showControls() {
        controlsVisible = true;
        controlsOverlay.setVisibility(View.VISIBLE);
        controlsOverlay.animate().alpha(1f).setDuration(180).start();
        scheduleAutoHide();
    }

    private void scheduleAutoHide() {
        uiHandler.removeCallbacks(hideControlsRunnable);
        uiHandler.postDelayed(hideControlsRunnable, 3500);
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void finishWithResult(boolean completed) {
        Intent d = new Intent();
        if (player != null) {
            d.putExtra("positionMs", player.getCurrentPosition());
            d.putExtra("durationMs", Math.max(0L, player.getDuration()));
        }
        d.putExtra("completed", completed);
        d.putExtra("nextRequested", nextRequested);
        setResult(RESULT_OK, d);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishWithResult(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        uiHandler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private String formatSpeed(float s) {
        return String.format(Locale.US, "%.2gx", s);
    }

    private String formatTime(long ms) {
        if (ms <= 0) return "00:00";
        long totalSec = ms / 1000;
        long h = totalSec / 3600;
        long m = (totalSec % 3600) / 60;
        long s = totalSec % 60;
        return h > 0
                ? String.format(Locale.US, "%d:%02d:%02d", h, m, s)
                : String.format(Locale.US, "%02d:%02d", m, s);
    }
}
