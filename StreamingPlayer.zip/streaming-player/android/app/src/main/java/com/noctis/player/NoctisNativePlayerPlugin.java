package com.noctis.player;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@CapacitorPlugin(name = "NoctisNativePlayer")
public class NoctisNativePlayerPlugin extends Plugin {
    @PluginMethod
    public void pickLocalVideos(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "video/x-matroska", "video/mp4", "video/webm", "video/quicktime", "video/x-msvideo", "application/octet-stream"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "handlePickVideosResult");
    }

    @ActivityCallback
    private void handlePickVideosResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject response = new JSObject();
        JSArray filesArray = new JSArray();
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Intent data = result.getData();
            List<Uri> uris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) { for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri()); }
            else if (data.getData() != null) uris.add(data.getData());
            ContentResolver resolver = getContext().getContentResolver();
            for (Uri uri : uris) {
                try { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                filesArray.put(extractVideoMetadata(uri));
            }
        }
        response.put("files", filesArray);
        call.resolve(response);
    }

    @PluginMethod
    public void pickSubtitleFile(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "handlePickSubtitleResult");
    }

    @ActivityCallback
    private void handlePickSubtitleResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) { call.resolve(new JSObject()); return; }
        Uri uri = result.getData().getData();
        try { getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        JSObject res = new JSObject();
        res.put("uri", uri.toString()); res.put("name", queryDisplayName(uri)); res.put("text", readTextFromUri(uri));
        call.resolve(res);
    }

    @PluginMethod
    public void playVideo(PluginCall call) {
        String uri = call.getString("uri", "");
        if (uri == null || uri.isEmpty()) { call.reject("URI vazia."); return; }
        Intent intent = new Intent(getContext(), NativePlayerActivity.class);
        intent.putExtra("uri", uri);
        intent.putExtra("title", call.getString("title", "Noctis Player"));
        intent.putExtra("subtitle", call.getString("subtitle", ""));
        intent.putExtra("subtitleUri", call.getString("subtitleUri", ""));
        intent.putExtra("startPositionMs", call.getInt("startPositionMs", 0).longValue());
        intent.putExtra("playbackSpeed", call.getFloat("playbackSpeed", 1.0f));
        intent.putExtra("preferredAudio", call.getString("preferredAudio", "pt"));
        intent.putExtra("preferredSubtitle", call.getString("preferredSubtitle", "pt"));
        intent.putExtra("hasNextEpisode", call.getBoolean("hasNextEpisode", false));
        startActivityForResult(call, intent, "handlePlayVideoResult");
    }

    @ActivityCallback
    private void handlePlayVideoResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject out = new JSObject();
        if (result.getData() != null) {
            Intent d = result.getData();
            out.put("positionMs", d.getLongExtra("positionMs", 0L));
            out.put("durationMs", d.getLongExtra("durationMs", 0L));
            out.put("completed", d.getBooleanExtra("completed", false));
            out.put("nextRequested", d.getBooleanExtra("nextRequested", false));
        } else { out.put("positionMs", 0L); out.put("durationMs", 0L); out.put("completed", false); out.put("nextRequested", false); }
        call.resolve(out);
    }

    @PluginMethod
    public void setBrightness(PluginCall call) {
        float level = call.getFloat("level", 0.8f);
        getActivity().runOnUiThread(() -> {
            WindowManager.LayoutParams lp = getActivity().getWindow().getAttributes();
            lp.screenBrightness = Math.max(0.05f, Math.min(1.0f, level));
            getActivity().getWindow().setAttributes(lp);
        });
        call.resolve();
    }

    @PluginMethod
    public void getDeviceInfo(PluginCall call) {
        JSObject info = new JSObject();
        info.put("platform", "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        info.put("engine", "AndroidX Media3 ExoPlayer 1.4.1 (Matroska/MKV)");
        call.resolve(info);
    }

    private JSObject extractVideoMetadata(Uri uri) {
        JSObject obj = new JSObject();
        obj.put("uri", uri.toString()); obj.put("name", queryDisplayName(uri));
        String mime = getContext().getContentResolver().getType(uri);
        obj.put("mimeType", mime != null ? mime : "video/*");
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        long durMs = 0L; String thumb = "";
        try {
            r.setDataSource(getContext(), uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (d != null) durMs = Long.parseLong(d);
            Bitmap f = r.getFrameAtTime(Math.min(2_000_000L, durMs * 500L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (f != null) {
                Bitmap sc = Bitmap.createScaledBitmap(f, 320, 180, true);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                sc.compress(Bitmap.CompressFormat.JPEG, 72, out);
                thumb = "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                f.recycle(); sc.recycle();
            }
        } catch (Exception ignored) {} finally { try { r.release(); } catch (Exception ignored) {} }
        obj.put("durationMs", durMs); obj.put("thumbnail", thumb);
        return obj;
    }

    private String queryDisplayName(Uri uri) {
        String name = "video.mkv";
        try (Cursor c = getContext().getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i); }
        } catch (Exception ignored) {}
        return name;
    }

    private String readTextFromUri(Uri uri) {
        StringBuilder sb = new StringBuilder();
        try (InputStream is = getContext().getContentResolver().openInputStream(uri); BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String l; while ((l = br.readLine()) != null) sb.append(l).append("\n");
        } catch (Exception ignored) {}
        return sb.toString();
    }
}
