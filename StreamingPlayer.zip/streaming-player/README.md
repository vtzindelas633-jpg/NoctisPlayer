# NOCTIS — Cinema Streaming Player (Android + Capacitor + Media3/ExoPlayer)

Aplicativo Android completo de filmes, séries, animes e reprodução local (prioridade máxima para **MKV**), construído com **HTML, CSS e JavaScript puro** (sem frameworks), empacotado com **Capacitor 6** e integrado ao **AndroidX Media3 / ExoPlayer 1.4.1**.

## Como Gerar o APK pelo GitHub Actions (sem PC)
1. Extraia `StreamingPlayer.zip` e envie os arquivos para um repositório no GitHub.
2. Abra a aba **Actions** → selecione **Build Noctis Android APK** → clique em **Run workflow**.
3. Baixe o artefato **Noctis-Debug-APK** (`app-debug.apk`) e instale no Android (Android 8.0 / API 26+).

### APK Release Assinado (Opcional)
Configure em **Settings → Secrets and variables → Actions**:
- `KEYSTORE_BASE64` (sua keystore `.jks` convertida com `base64 -w 0`)
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

### Extensão FFmpeg para MKV (AC3 / DTS / E-AC3 / FLAC)
Em `android/app/build.gradle`, descomente:
```gradle
implementation "org.jellyfin.media3:media3-ffmpeg-decoder:1.4.1+1"
```

### Integração TMDB (Opcional)
No aplicativo, acesse **Configurações → API TMDB (Opcional)** e insira sua chave v3 (armazenada apenas localmente no aparelho).
