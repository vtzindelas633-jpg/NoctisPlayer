const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const outDir = path.join(root, "www");
function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) copyRecursive(path.join(src, entry), path.join(dest, entry));
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}
if (fs.existsSync(outDir)) fs.rmSync(outDir, { recursive: true, force: true });
fs.mkdirSync(outDir, { recursive: true });
for (const item of ["index.html", "css", "js", "assets"]) {
  const srcPath = path.join(root, item);
  if (fs.existsSync(srcPath)) copyRecursive(srcPath, path.join(outDir, item));
}
console.log("[Noctis Build] Pasta www/ preparada com sucesso.");
