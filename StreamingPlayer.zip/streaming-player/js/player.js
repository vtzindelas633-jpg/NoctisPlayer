(function (global) {
  const st = { active: false, locked: false, controlsVisible: true, hideTimer: null, saveTimer: null, nextEpTimer: null, currentMedia: null, nextEpisodePayload: null, cues: [], subtitleEnabled: true, subtitleOffsetMs: 0, subtitleName: "Desativada", brightness: 1.0, quality: "Auto (Melhor)", speed: 1.0, lastTapTime: 0, gestureStart: null };
  let els = {};
  const fmt = (sec) => { if (!isFinite(sec) || sec < 0) return "00:00"; const s = Math.floor(sec), h = Math.floor(s/3600), m = Math.floor((s%3600)/60), r = s%60, p = (n) => String(n).padStart(2,"0"); return h > 0 ? `${h}:${p(m)}:${p(r)}` : `${p(m)}:${p(r)}`; };
  const isNativeFmt = (u) => { const l = String(u||"").toLowerCase(); return l.endsWith(".mkv") || l.includes("matroska") || l.startsWith("content://") || l.endsWith(".avi") || l.endsWith(".mov"); };

  function parseSub(text) {
    const cues = [], blocks = String(text||"").replace(/\r\n/g,"\n").replace(/\r/g,"\n").trim().split(/\n{2,}/);
    const rx = /(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})/;
    const toSec = (h,m,s,ms) => (h ? parseInt(h,10) : 0)*3600 + parseInt(m,10)*60 + parseInt(s,10) + parseInt(ms,10)/1000;
    for (const b of blocks) {
      const lines = b.split("\n"), idx = lines.findIndex((l) => rx.test(l));
      if (idx === -1) continue;
      const m = lines[idx].match(rx);
      const body = lines.slice(idx+1).join("\n").replace(/<[^>]+>/g,"").trim();
      if (m && body) cues.push({ start: toSec(m[1],m[2],m[3],m[4]), end: toSec(m[5],m[6],m[7],m[8]), text: body });
    }
    return cues;
  }

  function renderSub(t) {
    if (!st.subtitleEnabled || !st.cues.length) { els.subtitleBox.textContent = ""; return; }
    const shifted = t - st.subtitleOffsetMs / 1000;
    const c = st.cues.find((x) => shifted >= x.start && shifted <= x.end);
    els.subtitleBox.textContent = c ? c.text : "";
  }

  function showHud(txt) { els.gestureHud.textContent = txt; els.gestureHud.classList.remove("hidden"); clearTimeout(els.gestureHud._t); els.gestureHud._t = setTimeout(() => els.gestureHud.classList.add("hidden"), 900); }
  function flashSeek(d) { const el = d < 0 ? els.seekLeft : els.seekRight; el.classList.remove("hidden"); clearTimeout(el._t); el._t = setTimeout(() => el.classList.add("hidden"), 550); }
  function scheduleHide() {
    clearTimeout(st.hideTimer);
    if (!st.active || els.video.paused || !els.drawer.classList.contains("hidden")) return;
    st.hideTimer = setTimeout(() => { if (st.active && !els.video.paused && !st.locked) { st.controlsVisible = false; els.controls.classList.add("controls-hidden"); } }, 3400);
  }
  function showControls() { if (st.locked) return; st.controlsVisible = true; els.controls.classList.remove("controls-hidden"); scheduleHide(); }
  function updatePlayUI() { const p = els.video.paused; els.iconPlay.classList.toggle("hidden", !p); els.iconPause.classList.toggle("hidden", p); }

  async function saveProg() {
    if (!st.currentMedia || !els.video || !isFinite(els.video.duration) || els.video.duration <= 0) return;
    await global.NoctisStorage.saveWatchProgress({ ...st.currentMedia, position: els.video.currentTime, duration: els.video.duration });
  }

  function openDrawer(mode = "all") {
    els.drawer.classList.remove("hidden"); clearTimeout(st.hideTimer);
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0], quals = ["Auto (Melhor)", "1080p Full HD", "720p HD", "480p SD"];
    const aTracks = Array.from(els.video.audioTracks || []);
    els.drawerTitle.textContent = mode === "tracks" ? "Áudio & Legendas" : "Configurações do Player";
    els.drawerBody.innerHTML = `
      <div><div class="drawer-section-title">Velocidade</div><div class="drawer-options">${speeds.map((s) => `<button class="drawer-option-btn ${st.speed === s ? "active" : ""}" data-speed="${s}">${s}x</button>`).join("")}</div></div>
      <div><div class="drawer-section-title">Qualidade</div><div class="drawer-options">${quals.map((q) => `<button class="drawer-option-btn ${st.quality === q ? "active" : ""}" data-quality="${q}">${q}</button>`).join("")}</div></div>
      <div><div class="drawer-section-title">Faixas de Áudio</div><div class="drawer-options">${aTracks.length ? aTracks.map((t, i) => `<button class="drawer-option-btn ${t.enabled ? "active" : ""}" data-aidx="${i}">${t.label || t.language || "Faixa " + (i+1)}</button>`).join("") : `<button class="drawer-option-btn active">Original</button><div style="font-size:11.5px;color:var(--text-secondary);">Múltiplas faixas MKV são gerenciadas pelo Media3/ExoPlayer no Android.</div>`}</div></div>
      <div><div class="drawer-section-title">Legendas (${st.subtitleName})</div><div class="drawer-options" style="margin-bottom:10px;"><button id="btn-sub-toggle" class="drawer-option-btn ${st.subtitleEnabled ? "active" : ""}">${st.subtitleEnabled ? "Ativa" : "Desativada"}</button><button id="btn-sub-load" class="drawer-option-btn">Carregar .SRT/.VTT</button></div>
      <div class="drawer-section-title">Sincronização (${st.subtitleOffsetMs >= 0 ? "+" : ""}${st.subtitleOffsetMs}ms)</div><div class="drawer-options"><button class="drawer-option-btn" data-shift="-500">-500ms</button><button class="drawer-option-btn" data-shift="-100">-100ms</button><button class="drawer-option-btn" data-shift="0">0ms</button><button class="drawer-option-btn" data-shift="100">+100ms</button><button class="drawer-option-btn" data-shift="500">+500ms</button></div></div>`;
    els.drawerBody.querySelectorAll("[data-speed]").forEach((b) => b.addEventListener("click", () => { st.speed = parseFloat(b.dataset.speed); els.video.playbackRate = st.speed; els.btnSpeed.textContent = `${st.speed}x`; openDrawer(mode); }));
    els.drawerBody.querySelectorAll("[data-quality]").forEach((b) => b.addEventListener("click", () => { st.quality = b.dataset.quality; global.NoctisApp.toast(`Qualidade: ${st.quality}`); openDrawer(mode); }));
    els.drawerBody.querySelectorAll("[data-aidx]").forEach((b) => b.addEventListener("click", () => { const idx = parseInt(b.dataset.aidx, 10); for (let i = 0; i < (els.video.audioTracks||[]).length; i++) els.video.audioTracks[i].enabled = i === idx; openDrawer(mode); }));
    document.getElementById("btn-sub-toggle")?.addEventListener("click", () => { st.subtitleEnabled = !st.subtitleEnabled; renderSub(els.video.currentTime); openDrawer(mode); });
    document.getElementById("btn-sub-load")?.addEventListener("click", async () => {
      const r = await global.NoctisNative.pickSubtitleFile();
      if (r && r.text) { st.cues = parseSub(r.text); st.subtitleEnabled = true; st.subtitleName = r.name || "Legenda Externa"; global.NoctisApp.toast(`Legenda carregada (${st.cues.length} falas).`, "success"); openDrawer(mode); }
    });
    els.drawerBody.querySelectorAll("[data-shift]").forEach((b) => b.addEventListener("click", () => { const v = parseInt(b.dataset.shift, 10); st.subtitleOffsetMs = v === 0 ? 0 : st.subtitleOffsetMs + v; renderSub(els.video.currentTime); openDrawer(mode); }));
  }

  function startNextCountdown() {
    if (!st.nextEpisodePayload) return;
    clearInterval(st.nextEpTimer);
    let sec = 8;
    els.nextEpTitle.textContent = st.nextEpisodePayload.subtitle || st.nextEpisodePayload.title;
    els.nextEpCountdown.textContent = sec;
    els.nextEpCard.classList.remove("hidden");
    st.nextEpTimer = setInterval(() => {
      sec -= 1; els.nextEpCountdown.textContent = Math.max(0, sec);
      if (sec <= 0) { clearInterval(st.nextEpTimer); els.nextEpCard.classList.add("hidden"); NoctisPlayer.open(st.nextEpisodePayload); }
    }, 1000);
  }

  const NoctisPlayer = {
    init() {
      const $ = (id) => document.getElementById(id);
      els = { overlay: $("video-player-overlay"), stage: $("player-stage"), video: $("html5-video"), subtitleBox: $("player-subtitle-box"), spinner: $("player-spinner"), spinnerText: $("player-spinner-text"), controls: $("player-controls"), title: $("player-media-title"), subtitle: $("player-media-subtitle"), engineBadge: $("player-engine-badge"), btnBack: $("btn-player-back"), btnLock: $("btn-player-lock"), btnUnlock: $("btn-player-unlock"), btnSettings: $("btn-player-settings"), btnPlay: $("btn-player-play"), iconPlay: $("icon-play"), iconPause: $("icon-pause"), btnRew: $("btn-player-rew"), btnFwd: $("btn-player-fwd"), curTime: $("player-current-time"), durTime: $("player-duration"), scrubber: $("player-scrubber"), buffered: $("scrubber-buffered"), filled: $("scrubber-filled"), thumb: $("scrubber-thumb"), btnMute: $("btn-player-mute"), volSlider: $("player-volume-slider"), brightSlider: $("player-brightness-slider"), btnNextEp: $("btn-player-next-ep"), btnTracks: $("btn-player-tracks"), btnSpeed: $("btn-player-speed"), btnRotate: $("btn-player-rotate"), btnFullscreen: $("btn-player-fullscreen"), btnSkipIntro: $("btn-skip-intro"), nextEpCard: $("next-episode-card"), nextEpTitle: $("next-ep-title"), nextEpCountdown: $("next-ep-countdown"), btnNextEpNow: $("btn-next-ep-now"), btnNextEpCancel: $("btn-next-ep-cancel"), drawer: $("player-drawer"), drawerTitle: $("player-drawer-title"), drawerBody: $("player-drawer-body"), btnCloseDrawer: $("btn-close-drawer"), gestureHud: $("player-gesture-hud"), seekLeft: $("seek-feedback-left"), seekRight: $("seek-feedback-right") };

      els.btnBack.addEventListener("click", () => this.close());
      els.btnPlay.addEventListener("click", () => { if (els.video.paused) els.video.play().catch(()=>{}); else els.video.pause(); scheduleHide(); });
      els.btnRew.addEventListener("click", () => { els.video.currentTime = Math.max(0, els.video.currentTime - 10); flashSeek(-10); scheduleHide(); });
      els.btnFwd.addEventListener("click", () => { els.video.currentTime = Math.min(els.video.duration || els.video.currentTime + 10, els.video.currentTime + 10); flashSeek(10); scheduleHide(); });
      els.btnLock.addEventListener("click", () => { st.locked = true; els.controls.classList.add("controls-hidden"); els.btnUnlock.classList.remove("hidden"); els.drawer.classList.add("hidden"); });
      els.btnUnlock.addEventListener("click", () => { st.locked = false; els.btnUnlock.classList.add("hidden"); showControls(); });
      els.btnSettings.addEventListener("click", () => openDrawer("all"));
      els.btnTracks.addEventListener("click", () => openDrawer("tracks"));
      els.btnSpeed.addEventListener("click", () => openDrawer("all"));
      els.btnCloseDrawer.addEventListener("click", () => { els.drawer.classList.add("hidden"); scheduleHide(); });
      els.btnMute.addEventListener("click", () => { els.video.muted = !els.video.muted; els.volSlider.value = els.video.muted ? 0 : els.video.volume; });
      els.volSlider.addEventListener("input", () => { els.video.muted = false; els.video.volume = parseFloat(els.volSlider.value); });
      els.brightSlider.addEventListener("input", () => { st.brightness = parseFloat(els.brightSlider.value); els.video.style.filter = `brightness(${st.brightness})`; global.NoctisNative.setBrightness(st.brightness); });
      els.btnRotate.addEventListener("click", () => { const land = window.innerWidth > window.innerHeight; global.NoctisNative.setScreenOrientation(land ? "unlock" : "landscape"); });
      els.btnFullscreen.addEventListener("click", () => { if (!document.fullscreenElement) els.overlay.requestFullscreen?.().catch(()=>{}); else document.exitFullscreen?.().catch(()=>{}); });
      els.btnSkipIntro.addEventListener("click", () => { if (st.currentMedia?.introEndSec) { els.video.currentTime = st.currentMedia.introEndSec; els.btnSkipIntro.classList.add("hidden"); } });
      els.btnNextEp.addEventListener("click", () => { if (st.nextEpisodePayload) this.open(st.nextEpisodePayload); });
      els.btnNextEpNow.addEventListener("click", () => { clearInterval(st.nextEpTimer); els.nextEpCard.classList.add("hidden"); if (st.nextEpisodePayload) this.open(st.nextEpisodePayload); });
      els.btnNextEpCancel.addEventListener("click", () => { clearInterval(st.nextEpTimer); els.nextEpCard.classList.add("hidden"); });

      let scrub = false;
      const seekX = (x) => { const r = els.scrubber.getBoundingClientRect(); const ratio = Math.max(0, Math.min(1, (x - r.left)/r.width)); if (isFinite(els.video.duration)) els.video.currentTime = ratio * els.video.duration; };
      els.scrubber.addEventListener("pointerdown", (e) => { scrub = true; els.scrubber.setPointerCapture(e.pointerId); seekX(e.clientX); });
      els.scrubber.addEventListener("pointermove", (e) => { if (scrub) seekX(e.clientX); });
      els.scrubber.addEventListener("pointerup", () => { scrub = false; scheduleHide(); });

      els.stage.addEventListener("click", (e) => {
        if (e.target.closest(".player-top-bar,.player-bottom-bar,.player-center-controls,.player-drawer,.btn-player-unlock,.next-episode-card,.btn-skip-intro")) return;
        if (st.locked) { els.btnUnlock.classList.remove("hidden"); return; }
        const now = Date.now();
        if (now - st.lastTapTime < 280) {
          const left = e.clientX < els.stage.getBoundingClientRect().width / 2;
          els.video.currentTime = Math.max(0, Math.min(els.video.duration || 0, els.video.currentTime + (left ? -10 : 10)));
          flashSeek(left ? -10 : 10);
        } else {
          if (st.controlsVisible) { st.controlsVisible = false; els.controls.classList.add("controls-hidden"); } else showControls();
        }
        st.lastTapTime = now;
      });

      els.stage.addEventListener("touchstart", (e) => {
        if (st.locked || e.touches.length !== 1) return;
        st.gestureStart = { y: e.touches[0].clientY, side: e.touches[0].clientX < window.innerWidth / 2 ? "left" : "right", vol: els.video.volume, bright: st.brightness };
      }, { passive: true });
      els.stage.addEventListener("touchmove", (e) => {
        if (!st.gestureStart || st.locked || e.touches.length !== 1) return;
        const dy = st.gestureStart.y - e.touches[0].clientY;
        if (Math.abs(dy) < 18) return;
        const d = dy / 220;
        if (st.gestureStart.side === "left") {
          st.brightness = Math.max(0.3, Math.min(1.0, st.gestureStart.bright + d));
          els.video.style.filter = `brightness(${st.brightness})`; els.brightSlider.value = st.brightness.toFixed(2);
          global.NoctisNative.setBrightness(st.brightness); showHud(`Brilho ${Math.round(st.brightness*100)}%`);
        } else {
          const nv = Math.max(0, Math.min(1, st.gestureStart.vol + d));
          els.video.muted = false; els.video.volume = nv; els.volSlider.value = nv.toFixed(2); showHud(`Volume ${Math.round(nv*100)}%`);
        }
      }, { passive: true });
      els.stage.addEventListener("touchend", () => { st.gestureStart = null; });

      els.video.addEventListener("waiting", () => els.spinner.classList.remove("hidden"));
      els.video.addEventListener("playing", () => { els.spinner.classList.add("hidden"); updatePlayUI(); scheduleHide(); });
      els.video.addEventListener("pause", () => { updatePlayUI(); showControls(); saveProg(); });
      els.video.addEventListener("loadedmetadata", () => {
        els.durTime.textContent = fmt(els.video.duration);
        if (st.currentMedia?.resumePosition > 3 && st.currentMedia.resumePosition < els.video.duration - 5) els.video.currentTime = st.currentMedia.resumePosition;
        els.video.playbackRate = st.speed;
      });
      els.video.addEventListener("timeupdate", () => {
        const cur = els.video.currentTime, dur = els.video.duration || 0;
        els.curTime.textContent = fmt(cur);
        if (dur > 0) {
          const pct = (cur / dur) * 100; els.filled.style.width = `${pct}%`; els.thumb.style.left = `${pct}%`;
          if (els.video.buffered.length) els.buffered.style.width = `${Math.min(100, (els.video.buffered.end(els.video.buffered.length - 1)/dur)*100)}%`;
        }
        renderSub(cur);
        els.btnSkipIntro.classList.toggle("hidden", !(st.currentMedia?.introEndSec && cur >= 2 && cur < st.currentMedia.introEndSec));
      });
      els.video.addEventListener("ended", async () => {
        await saveProg();
        const s = await global.NoctisStorage.getProfileSettings();
        if (st.nextEpisodePayload && s.autoPlayNext) startNextCountdown(); else showControls();
      });
      els.video.addEventListener("error", () => {
        els.spinner.classList.add("hidden");
        global.NoctisApp.toast("Codec incompatível no player web. No Android, MKV usa Media3/ExoPlayer nativo.", "error");
      });
    },
    isOpen() { return st.active; },
    async open(payload) {
      if (!payload || !payload.sourceUrl) return global.NoctisApp.toast("Nenhuma fonte de vídeo vinculada.", "error");
      const s = await global.NoctisStorage.getProfileSettings();
      const saved = await global.NoctisStorage.getMediaProgress(payload.mediaId, payload.episodeId);
      const resumePos = payload.startPosition != null ? payload.startPosition : (saved && saved.percent < 95 ? saved.position : 0);

      if (global.NoctisNative.hasNativePlayer() && (isNativeFmt(payload.sourceUrl) || s.preferNativePlayer)) {
        try {
          const res = await global.NoctisNative.playWithNativeExoPlayer({
            uri: payload.sourceUrl, title: payload.title, subtitle: payload.subtitle || "",
            subtitleUri: payload.subtitleUri || "", startPosition: resumePos, speed: s.defaultSpeed || 1.0,
            preferredAudio: s.preferredAudio || "pt", preferredSubtitle: s.preferredSubtitle || "pt", hasNextEpisode: !!payload.nextEpisodePayload
          });
          if (res && res.durationMs > 0) await global.NoctisStorage.saveWatchProgress({ ...payload, position: res.positionMs / 1000, duration: res.durationMs / 1000 });
          if (res && res.nextRequested && payload.nextEpisodePayload) return this.open(payload.nextEpisodePayload);
          global.NoctisNav.refreshCurrentView();
          return;
        } catch (_) {}
      }

      st.active = true; st.locked = false; st.currentMedia = { ...payload, resumePosition: resumePos };
      st.nextEpisodePayload = payload.nextEpisodePayload || null; st.speed = Number(s.defaultSpeed) || 1.0;
      st.cues = []; st.subtitleOffsetMs = 0; st.subtitleName = "Desativada";
      els.subtitleBox.textContent = ""; els.nextEpCard.classList.add("hidden"); els.drawer.classList.add("hidden"); els.btnUnlock.classList.add("hidden");
      els.btnNextEp.classList.toggle("hidden", !st.nextEpisodePayload);
      els.title.textContent = payload.title || "Noctis"; els.subtitle.textContent = payload.subtitle || "";
      els.engineBadge.textContent = isNativeFmt(payload.sourceUrl) ? "MKV / MEDIA3 READY" : "NOCTIS ENGINE";
      els.btnSpeed.textContent = `${st.speed}x`;
      els.overlay.classList.remove("hidden"); els.spinner.classList.remove("hidden"); showControls();
      els.video.src = payload.sourceUrl; els.video.load();
      els.video.play().catch(() => { els.spinner.classList.add("hidden"); updatePlayUI(); });
      clearInterval(st.saveTimer); st.saveTimer = setInterval(saveProg, 5000);
    },
    async close() {
      if (!st.active) return;
      await saveProg(); clearInterval(st.saveTimer); clearInterval(st.nextEpTimer); clearTimeout(st.hideTimer);
      els.video.pause(); els.video.removeAttribute("src"); els.video.load();
      els.overlay.classList.add("hidden"); els.drawer.classList.add("hidden"); els.nextEpCard.classList.add("hidden");
      st.active = false;
      if (document.fullscreenElement) document.exitFullscreen?.().catch(()=>{});
      global.NoctisNative.setScreenOrientation("unlock");
      global.NoctisNav.refreshCurrentView();
    }
  };
  global.NoctisPlayer = NoctisPlayer;
})(window);
