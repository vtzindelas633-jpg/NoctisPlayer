(function (global) {
  function getCap() { return global.Capacitor || null; }
  function isNativeAndroid() {
    const cap = getCap();
    return !!(cap && typeof cap.isNativePlatform === "function" && cap.isNativePlatform() && cap.getPlatform() === "android");
  }
  function getPlugin() {
    const cap = getCap();
    return cap && cap.Plugins ? cap.Plugins.NoctisNativePlayer || null : null;
  }
  function guessMime(name) {
    const ext = (name.split(".").pop() || "").toLowerCase();
    return { mkv: "video/x-matroska", mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", avi: "video/x-msvideo" }[ext] || "video/*";
  }
  function extractWebMeta(url) {
    return new Promise((resolve) => {
      const v = document.createElement("video");
      v.preload = "metadata"; v.muted = true; v.src = url;
      const done = (thumb = "") => resolve({ durationMs: isFinite(v.duration) ? Math.round(v.duration * 1000) : 0, thumbnail: thumb });
      const t = setTimeout(() => done(""), 2200);
      v.onloadeddata = () => { try { v.currentTime = Math.min(2, (v.duration || 4) * 0.15); } catch (_) { clearTimeout(t); done(""); } };
      v.onseeked = () => {
        clearTimeout(t);
        try {
          const c = document.createElement("canvas"); c.width = 320; c.height = 180;
          c.getContext("2d").drawImage(v, 0, 0, 320, 180);
          done(c.toDataURL("image/jpeg", 0.72));
        } catch (_) { done(""); }
      };
      v.onerror = () => { clearTimeout(t); done(""); };
    });
  }

  global.NoctisNative = {
    isNativeAndroid,
    hasNativePlayer() { return isNativeAndroid() && !!getPlugin(); },
    async pickLocalVideos() {
      const plugin = getPlugin();
      if (this.hasNativePlayer() && plugin.pickLocalVideos) {
        const res = await plugin.pickLocalVideos();
        return res && Array.isArray(res.files) ? res.files : [];
      }
      return new Promise((resolve) => {
        const input = document.getElementById("web-local-video-input");
        if (!input) return resolve([]);
        input.value = "";
        const handler = async () => {
          input.removeEventListener("change", handler);
          const parsed = [];
          for (const file of Array.from(input.files || [])) {
            const url = URL.createObjectURL(file);
            const meta = await extractWebMeta(url);
            parsed.push({ uri: url, name: file.name, size: file.size, mimeType: file.type || guessMime(file.name), durationMs: meta.durationMs, thumbnail: meta.thumbnail, isWebObjectUrl: true });
          }
          resolve(parsed);
        };
        input.addEventListener("change", handler);
        input.click();
      });
    },
    async pickSubtitleFile() {
      const plugin = getPlugin();
      if (this.hasNativePlayer() && plugin.pickSubtitleFile) return await plugin.pickSubtitleFile();
      return new Promise((resolve) => {
        const input = document.getElementById("external-subtitle-input");
        if (!input) return resolve(null);
        input.value = "";
        const handler = () => {
          input.removeEventListener("change", handler);
          const f = input.files && input.files[0];
          if (!f) return resolve(null);
          const r = new FileReader();
          r.onload = () => resolve({ name: f.name, text: r.result, uri: null });
          r.onerror = () => resolve(null);
          r.readAsText(f, "utf-8");
        };
        input.addEventListener("change", handler);
        input.click();
      });
    },
    async playWithNativeExoPlayer(opts) {
      const plugin = getPlugin();
      if (!this.hasNativePlayer() || !plugin.playVideo) throw new Error("Plugin nativo indisponível.");
      return await plugin.playVideo({
        uri: opts.uri, title: opts.title || "Noctis", subtitle: opts.subtitle || "",
        subtitleUri: opts.subtitleUri || "", startPositionMs: Math.round((opts.startPosition || 0) * 1000),
        playbackSpeed: Number(opts.speed || 1.0), preferredAudio: opts.preferredAudio || "pt",
        preferredSubtitle: opts.preferredSubtitle || "pt", hasNextEpisode: !!opts.hasNextEpisode
      });
    },
    async setScreenOrientation(mode) {
      try {
        const cap = getCap();
        if (cap && cap.Plugins && cap.Plugins.ScreenOrientation) {
          if (mode === "landscape") await cap.Plugins.ScreenOrientation.lock({ orientation: "landscape" });
          else await cap.Plugins.ScreenOrientation.unlock();
        } else if (screen.orientation) {
          if (mode === "landscape" && screen.orientation.lock) await screen.orientation.lock("landscape").catch(() => {});
          else if (screen.orientation.unlock) screen.orientation.unlock();
        }
      } catch (_) {}
    },
    async setBrightness(level) {
      const plugin = getPlugin();
      if (this.hasNativePlayer() && plugin.setBrightness) {
        try { await plugin.setBrightness({ level: Math.max(0.05, Math.min(1.0, level)) }); } catch (_) {}
      }
    },
    async getTechnicalInfo() {
      const plugin = getPlugin();
      if (this.hasNativePlayer() && plugin.getDeviceInfo) {
        try { return await plugin.getDeviceInfo(); } catch (_) {}
      }
      return {
        platform: isNativeAndroid() ? "Android (Capacitor)" : "Web Preview / Navegador",
        engine: isNativeAndroid() ? "Media3 ExoPlayer 1.4.1 (Matroska/MKV)" : "HTML5 Video Engine"
      };
    },
    registerBackButton(cb) {
      const cap = getCap();
      if (cap && cap.Plugins && cap.Plugins.App) cap.Plugins.App.addListener("backButton", cb);
    }
  };
})(window);
