(function (global) {
  let currentRoute = "home";
  const stack = ["home"], SUBTABS = new Set(["home", "movies", "series", "animes", "mylist"]);
  global.NoctisNav = {
    getCurrentRoute() { return currentRoute; },
    async go(route, push = true) {
      currentRoute = route || "home";
      if (push && stack[stack.length - 1] !== currentRoute) stack.push(currentRoute);
      document.querySelectorAll("[data-route]").forEach((el) => el.classList.toggle("active", el.dataset.route === currentRoute));
      document.getElementById("mobile-subtabs")?.classList.toggle("hidden-tabs", !SUBTABS.has(currentRoute));
      window.scrollTo({ top: 0, behavior: "smooth" });
      await this.renderRoute(currentRoute);
    },
    async refreshCurrentView() { await this.renderRoute(currentRoute); },
    async renderRoute(r) {
      const c = document.getElementById("main-content");
      if (!c) return;
      c.innerHTML = `<div style="padding:90px 20px;"><div class="skeleton" style="height:240px;margin-bottom:20px;"></div></div>`;
      if (r === "home") await global.NoctisCatalog.renderHome(c);
      else if (["movies", "series", "animes", "mylist"].includes(r)) await global.NoctisCatalog.renderCategoryView(c, r);
      else if (r === "local") await global.NoctisCatalog.renderLocalVideosView(c);
      else if (r === "search") await global.NoctisSearch.render(c);
      else if (r === "profile") await global.NoctisProfiles.renderProfileView(c);
      else if (r === "settings") await global.NoctisSettings.render(c);
      else await global.NoctisCatalog.renderHome(c);
    },
    handleAndroidBack() {
      if (global.NoctisPlayer.isOpen()) return global.NoctisPlayer.close();
      const m = document.getElementById("modal-backdrop");
      if (m && !m.classList.contains("hidden")) return global.NoctisApp.closeModal();
      if (stack.length > 1) { stack.pop(); this.go(stack[stack.length - 1], false); }
    }
  };
})(window);
