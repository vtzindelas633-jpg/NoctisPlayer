(function (global) {
  global.NoctisApp = {
    toast(msg, type = "info") {
      const box = document.getElementById("toast-container");
      if (!box) return;
      const el = document.createElement("div");
      el.className = `toast ${type}`; el.textContent = msg; box.appendChild(el);
      setTimeout(() => { el.style.opacity = "0"; setTimeout(() => el.remove(), 260); }, 2800);
    },
    openModal(html) {
      const b = document.getElementById("modal-backdrop"), c = document.getElementById("modal-container");
      if (!b || !c) return;
      c.innerHTML = html; b.classList.remove("hidden");
      c.querySelector("#btn-close-modal")?.addEventListener("click", () => this.closeModal());
    },
    closeModal() { document.getElementById("modal-backdrop")?.classList.add("hidden"); },
    async bootstrap() {
      try {
        await global.NoctisStorage.init();
        await global.NoctisProfiles.ensureDefaultProfile();
        await global.NoctisCatalog.seedIfEmpty();
        await global.NoctisSettings.applySavedAppearance();
        global.NoctisPlayer.init();
        const p = await global.NoctisProfiles.getActiveProfile();
        const av = document.getElementById("top-profile-avatar");
        if (av && p) av.src = p.avatar;
        document.querySelectorAll("[data-route]").forEach((el) => el.addEventListener("click", () => global.NoctisNav.go(el.dataset.route)));
        document.getElementById("btn-brand-home").addEventListener("click", () => global.NoctisNav.go("home"));
        document.getElementById("btn-top-add").addEventListener("click", () => global.NoctisCatalog.openAddContentModal());
        document.getElementById("btn-gate-add-profile").addEventListener("click", () => global.NoctisProfiles.openProfileModal(null));
        document.getElementById("modal-backdrop").addEventListener("click", (e) => { if (e.target.id === "modal-backdrop") this.closeModal(); });
        window.addEventListener("scroll", () => document.getElementById("top-bar").classList.toggle("scrolled", window.scrollY > 24), { passive: true });
        global.NoctisNative.registerBackButton(() => global.NoctisNav.handleAndroidBack());
        await global.NoctisNav.go("home", false);
      } catch (err) {
        console.error(err);
      } finally {
        setTimeout(() => document.getElementById("splash-screen")?.classList.add("fade-out"), 800);
      }
    }
  };
  document.addEventListener("DOMContentLoaded", () => global.NoctisApp.bootstrap());
})(window);
