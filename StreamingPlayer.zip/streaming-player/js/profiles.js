(function (global) {
  const AVATARS = [1, 2, 3, 4, 5, 6].map((n) => `assets/images/avatars/avatar-${n}.svg`);
  const esc = (s) => String(s || "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));

  global.NoctisProfiles = {
    AVATARS,
    async ensureDefaultProfile() {
      const list = await global.NoctisStorage.getAll("profiles");
      if (!list.length) {
        const def = { id: "profile-default", name: "Principal", avatar: AVATARS[0], createdAt: Date.now() };
        await global.NoctisStorage.put("profiles", def);
        global.NoctisStorage.setActiveProfileId(def.id);
        return [def];
      }
      if (!list.some((p) => p.id === global.NoctisStorage.getActiveProfileId())) {
        global.NoctisStorage.setActiveProfileId(list[0].id);
      }
      return list;
    },
    async getAll() { return this.ensureDefaultProfile(); },
    async getActiveProfile() {
      const list = await this.ensureDefaultProfile();
      return list.find((p) => p.id === global.NoctisStorage.getActiveProfileId()) || list[0];
    },
    async switchProfile(id) {
      global.NoctisStorage.setActiveProfileId(id);
      const p = await this.getActiveProfile();
      await global.NoctisSettings.applySavedAppearance();
      const av = document.getElementById("top-profile-avatar");
      if (av && p) av.src = p.avatar;
      global.NoctisApp.toast(`Perfil ativo: ${p.name}`, "success");
      document.getElementById("profile-gate")?.classList.add("hidden");
      global.NoctisNav.refreshCurrentView();
    },
    openProfileModal(existing = null) {
      const isEdit = !!existing;
      const selAv = existing ? existing.avatar : AVATARS[0];
      global.NoctisApp.openModal(`
        <div class="modal-header"><h3>${isEdit ? "Editar Perfil" : "Novo Perfil"}</h3><button class="icon-btn" id="btn-close-modal">✕</button></div>
        <div class="modal-body">
          <form id="profile-form" class="form-grid">
            <div class="form-group"><label>Nome</label><input id="prof-name" class="form-input" required maxlength="24" value="${isEdit ? esc(existing.name) : ""}" /></div>
            <div class="form-group"><label>Avatar</label>
              <div class="profile-grid" style="margin-bottom:6px;">
                ${AVATARS.map((a) => `<button type="button" class="profile-card avatar-pick ${a === selAv ? "active" : ""}" data-avatar="${a}" style="padding:10px;"><img src="${a}" style="width:56px;height:56px;" /></button>`).join("")}
              </div>
              <input type="hidden" id="prof-avatar" value="${selAv}" />
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;">
              ${isEdit ? `<button type="button" id="btn-del-profile" class="btn btn-danger">Excluir</button>` : ""}
              <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
          </form>
        </div>
      `);
      document.querySelectorAll(".avatar-pick").forEach((b) => b.addEventListener("click", () => {
        document.querySelectorAll(".avatar-pick").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        document.getElementById("prof-avatar").value = b.dataset.avatar;
      }));
      document.getElementById("btn-del-profile")?.addEventListener("click", async () => {
        if ((await this.getAll()).length <= 1) return global.NoctisApp.toast("Mantenha ao menos um perfil.", "error");
        await global.NoctisStorage.delete("profiles", existing.id);
        await this.ensureDefaultProfile();
        global.NoctisApp.closeModal();
        global.NoctisNav.refreshCurrentView();
      });
      document.getElementById("profile-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const rec = { id: isEdit ? existing.id : `profile-${Date.now()}`, name: document.getElementById("prof-name").value.trim(), avatar: document.getElementById("prof-avatar").value, createdAt: isEdit ? existing.createdAt : Date.now() };
        await global.NoctisStorage.put("profiles", rec);
        global.NoctisApp.closeModal();
        await this.switchProfile(rec.id);
      });
    },
    async renderProfileView(container) {
      const active = await this.getActiveProfile();
      const profiles = await this.getAll();
      const hist = await global.NoctisStorage.getProfileHistory();
      const favs = await global.NoctisStorage.getProfileFavorites();
      container.innerHTML = `
        <section class="page-view no-subtabs">
          <div class="page-header">
            <div><h1 class="page-title">Perfis &amp; Conta Local</h1><p class="page-subtitle">Histórico, favoritos e preferências isolados por perfil.</p></div>
            <div style="display:flex;gap:10px;"><button id="btn-prof-new" class="btn btn-primary btn-sm">+ Novo Perfil</button><button id="btn-prof-settings" class="btn btn-secondary btn-sm">Configurações</button></div>
          </div>
          <div class="settings-card" style="margin-bottom:20px;display:flex;align-items:center;gap:18px;flex-wrap:wrap;">
            <img src="${active.avatar}" style="width:76px;height:76px;border-radius:50%;border:3px solid var(--accent);" />
            <div style="flex:1;"><div style="font-size:20px;font-weight:800;">${esc(active.name)}</div><div style="font-size:13px;color:var(--text-secondary);">${hist.length} no histórico • ${favs.length} na Minha Lista</div></div>
            <button id="btn-edit-active-prof" class="btn btn-secondary btn-sm">Editar</button>
          </div>
          <div class="profile-grid">
            ${profiles.map((p) => `<div class="profile-card ${p.id === active.id ? "active" : ""}" data-switch="${p.id}"><img src="${p.avatar}" /><span>${esc(p.name)}</span><button class="btn btn-ghost btn-sm" data-edit="${p.id}">Editar</button></div>`).join("")}
          </div>
        </section>`;
      document.getElementById("btn-prof-new").addEventListener("click", () => this.openProfileModal(null));
      document.getElementById("btn-prof-settings").addEventListener("click", () => global.NoctisNav.go("settings"));
      document.getElementById("btn-edit-active-prof").addEventListener("click", () => this.openProfileModal(active));
      container.querySelectorAll("[data-switch]").forEach((c) => c.addEventListener("click", (e) => { if (!e.target.closest("[data-edit]")) this.switchProfile(c.dataset.switch); }));
      container.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); const p = profiles.find((x) => x.id === b.dataset.edit); if (p) this.openProfileModal(p); }));
    }
  };
})(window);
