(function (global) {
  const esc = (s) => String(s || "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  global.NoctisSearch = {
    async render(container) {
      global.NoctisCatalog.stopHeroTimer();
      const catalog = await global.NoctisCatalog.getAllCatalog();
      const hist = await global.NoctisStorage.getSearchHistory();
      const genres = Array.from(new Set(catalog.flatMap((c) => c.genres || []))).sort();
      container.innerHTML = `
        <section class="page-view no-subtabs">
          <div class="page-header"><div><h1 class="page-title">Pesquisa</h1><p class="page-subtitle">Filme, série, anime, ator, diretor, gênero ou ano.</p></div></div>
          <div class="search-bar-box"><span class="search-icon-left">🔍</span><input id="search-input" class="search-input-main" type="search" placeholder="Digite para pesquisar..." autocomplete="off" /><button id="btn-search-clear" class="search-clear-btn hidden">✕</button></div>
          <div class="filter-bar">
            <select id="f-type" class="form-select" style="width:auto;"><option value="all">Todos os tipos</option><option value="movie">Filmes</option><option value="series">Séries</option><option value="anime">Animes</option></select>
            <select id="f-genre" class="form-select" style="width:auto;"><option value="all">Todos os gêneros</option>${genres.map((g) => `<option value="${esc(g)}">${esc(g)}</option>`).join("")}</select>
            <select id="f-sort" class="form-select" style="width:auto;"><option value="rel">Relevância</option><option value="yd">Mais recentes</option><option value="ya">Mais antigos</option><option value="az">Título (A–Z)</option></select>
          </div>
          <div id="sh-box">${hist.length ? `<div style="display:flex;justify-content:space-between;margin-bottom:8px;"><span style="font-size:12px;color:var(--text-secondary);">RECENTES</span><button id="btn-clr-sh" class="btn btn-ghost btn-sm">Limpar</button></div><div class="chip-list">${hist.map((h) => `<button class="chip" data-ht="${esc(h.term)}">${esc(h.term)}</button>`).join("")}</div>` : ""}</div>
          <div id="s-sugg" class="chip-list"></div>
          <div id="s-res"></div>
        </section>`;
      const inp = document.getElementById("search-input"), clr = document.getElementById("btn-search-clear"), ft = document.getElementById("f-type"), fg = document.getElementById("f-genre"), fs = document.getElementById("f-sort"), resBox = document.getElementById("s-res"), sugBox = document.getElementById("s-sugg");
      const run = () => {
        const q = inp.value.trim().toLowerCase();
        clr.classList.toggle("hidden", !q);
        let list = catalog.filter((i) => {
          if (ft.value !== "all" && i.type !== ft.value) return false;
          if (fg.value !== "all" && !(i.genres||[]).includes(fg.value)) return false;
          if (!q) return true;
          return [i.title, i.director, String(i.year||""), ...(i.cast||[]), ...(i.genres||[]), i.synopsis].join(" ").toLowerCase().includes(q);
        });
        if (fs.value === "yd") list.sort((a,b) => (b.year||0)-(a.year||0));
        else if (fs.value === "ya") list.sort((a,b) => (a.year||0)-(b.year||0));
        else if (fs.value === "az") list.sort((a,b) => a.title.localeCompare(b.title));
        sugBox.innerHTML = q.length >= 2 ? list.slice(0, 5).map((f) => `<button class="chip" data-sg="${esc(f.title)}">🔎 ${esc(f.title)}</button>`).join("") : "";
        sugBox.querySelectorAll("[data-sg]").forEach((b) => b.addEventListener("click", () => { inp.value = b.dataset.sg; global.NoctisStorage.addSearchTerm(b.dataset.sg); run(); }));
        resBox.innerHTML = list.length ? `<div style="font-size:12.5px;color:var(--text-secondary);margin-bottom:12px;">${list.length} resultado(s)</div><div class="catalog-grid">${list.map((i) => global.NoctisCatalog.buildPosterCard(i)).join("")}</div>` : `<div class="empty-state"><h3>Nenhum resultado</h3></div>`;
        global.NoctisCatalog.bindCatalogInteractions(resBox);
      };
      inp.addEventListener("input", run);
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && inp.value.trim()) global.NoctisStorage.addSearchTerm(inp.value.trim()); });
      clr.addEventListener("click", () => { inp.value = ""; run(); });
      [ft, fg, fs].forEach((el) => el.addEventListener("change", run));
      container.querySelectorAll("[data-ht]").forEach((b) => b.addEventListener("click", () => { inp.value = b.dataset.ht; run(); }));
      document.getElementById("btn-clr-sh")?.addEventListener("click", async () => { await global.NoctisStorage.clearSearchHistory(); document.getElementById("sh-box").innerHTML = ""; });
      run();
    }
  };
})(window);
