(function (global) {
  let heroTimer = null, heroIndex = 0;
  const SECTIONS = ["Lançamentos", "Filmes populares", "Séries populares", "Animes", "Documentários", "Ação", "Ficção científica", "Terror", "Comédia", "Drama", "Recomendados"];
  const esc = (s) => String(s || "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const fmtMs = (ms) => { if (!ms || !isFinite(ms)) return "Duração desconhecida"; const s = Math.floor(ms/1000), h = Math.floor(s/3600), m = Math.floor((s%3600)/60), r = s%60; return h > 0 ? `${h}h ${m}m` : `${m}m ${String(r).padStart(2,"0")}s`; };
  const extOf = (n) => { const e = (String(n||"").split(".").pop() || "VIDEO").toUpperCase(); return e.length <= 5 ? e : "VIDEO"; };

  global.NoctisCatalog = {
    async seedIfEmpty() {
      if (!(await global.NoctisStorage.getAll("catalog")).length) {
        for (const it of global.NoctisDefaultCatalog) await global.NoctisStorage.put("catalog", it);
      }
    },
    async getAllCatalog() { await this.seedIfEmpty(); return global.NoctisStorage.getAll("catalog"); },
    stopHeroTimer() { clearInterval(heroTimer); heroTimer = null; },

    buildPosterCard(it) {
      const badge = it.type === "series" ? "SÉRIE" : it.type === "anime" ? "ANIME" : (it.format || "HD").split(" ")[0];
      return `<article class="poster-card" data-open-detail="${it.id}" tabindex="0"><div class="poster-thumb-wrap"><img src="${esc(it.poster)}" alt="${esc(it.title)}" loading="lazy" /><div class="poster-top-badges"><span class="badge badge-accent">${esc(badge)}</span><span class="badge">${esc(it.rating || "12+")}</span></div></div><div class="poster-info"><div class="poster-title">${esc(it.title)}</div><div class="poster-sub"><span>${it.year || 2025}</span><span>${esc(it.duration || "")}</span></div></div></article>`;
    },

    async renderHome(container) {
      this.stopHeroTimer();
      const catalog = await this.getAllCatalog();
      const history = await global.NoctisStorage.getProfileHistory();
      const favIds = new Set((await global.NoctisStorage.getProfileFavorites()).map((f) => f.mediaId));
      const myList = catalog.filter((c) => favIds.has(c.id));
      const heroList = catalog.filter((c) => c.featured);
      const heroes = heroList.length ? heroList : catalog.slice(0, 4);
      heroIndex %= heroes.length;

      let rows = "";
      if (history.length) {
        rows += `<section class="media-row"><div class="media-row-header"><h2 class="media-row-title">Continue assistindo</h2><span class="media-row-count">${history.length} item(ns)</span></div><div class="media-carousel">${history.map((h) => `<article class="continue-card" data-resume-id="${esc(h.id)}"><div class="continue-thumb"><img src="${esc(h.banner || h.poster || "assets/images/banners/meridian.svg")}" loading="lazy" /><div class="continue-play-overlay"><div class="continue-play-circle">▶</div></div><button class="continue-remove-btn" data-remove-history="${esc(h.id)}">✕</button><div class="continue-progress-bar"><div class="continue-progress-fill" style="width:${h.percent||0}%"></div></div></div><div class="continue-meta"><div class="continue-title">${esc(h.title)}</div><div class="continue-ep">${esc(h.subtitle || `${h.percent||0}% concluído`)}</div></div></article>`).join("")}</div></section>`;
      }
      for (const sec of SECTIONS) {
        const items = catalog.filter((i) => (i.categories && i.categories.includes(sec)) || (i.genres && i.genres.includes(sec)));
        if (items.length) rows += `<section class="media-row"><div class="media-row-header"><h2 class="media-row-title">${esc(sec)}</h2><span class="media-row-count">${items.length} títulos</span></div><div class="media-carousel">${items.map((it) => this.buildPosterCard(it)).join("")}</div></section>`;
      }
      if (myList.length) {
        rows += `<section class="media-row"><div class="media-row-header"><h2 class="media-row-title">Minha lista</h2><span class="media-row-count">${myList.length} salvos</span></div><div class="media-carousel">${myList.map((it) => this.buildPosterCard(it)).join("")}</div></section>`;
      }

      container.innerHTML = `<section id="hero-banner" class="hero-section"></section><div class="home-rows">${rows}</div>`;
      const drawHero = (idx) => {
        const it = heroes[idx], el = document.getElementById("hero-banner");
        if (!el || !it) return;
        el.innerHTML = `<div class="hero-backdrop" style="background-image:url('${esc(it.banner || it.poster)}')"></div><div class="hero-gradient"></div><div class="hero-content"><div class="hero-highlight-tag">★ DESTAQUE NOCTIS • ${it.type === "series" ? "SÉRIE" : it.type === "anime" ? "ANIME" : "FILME"}</div><h1 class="hero-title">${esc(it.title)}</h1><div class="hero-meta"><span class="badge badge-gold">${esc(it.rating||"12+")}</span><span>${it.year}</span><span class="dot"></span><span>${esc((it.genres||[]).join(" • "))}</span><span class="dot"></span><span>${esc(it.duration||"")}</span></div><p class="hero-synopsis">${esc(it.synopsis)}</p><div class="hero-actions"><button class="btn btn-primary" id="btn-hero-play">▶ Assistir agora</button><button class="btn btn-secondary" id="btn-hero-info">Mais informações</button></div><div class="hero-dots">${heroes.map((_, i) => `<button class="hero-dot ${i===idx?"active":""}" data-hidx="${i}"></button>`).join("")}</div></div>`;
        document.getElementById("btn-hero-play").addEventListener("click", () => this.playCatalogItem(it));
        document.getElementById("btn-hero-info").addEventListener("click", () => this.openDetailModal(it.id));
        el.querySelectorAll("[data-hidx]").forEach((d) => d.addEventListener("click", () => { heroIndex = parseInt(d.dataset.hidx, 10); drawHero(heroIndex); }));
      };
      drawHero(heroIndex);
      heroTimer = setInterval(() => { if (!document.getElementById("hero-banner")) return this.stopHeroTimer(); heroIndex = (heroIndex + 1) % heroes.length; drawHero(heroIndex); }, 7500);
      this.bindCatalogInteractions(container, history);
    },

    bindCatalogInteractions(container, hist = []) {
      container.querySelectorAll("[data-open-detail]").forEach((c) => c.addEventListener("click", () => this.openDetailModal(c.dataset.openDetail)));
      container.querySelectorAll("[data-remove-history]").forEach((b) => b.addEventListener("click", async (e) => { e.stopPropagation(); await global.NoctisStorage.removeHistoryItem(b.dataset.removeHistory); global.NoctisApp.toast("Removido do histórico."); global.NoctisNav.refreshCurrentView(); }));
      container.querySelectorAll("[data-resume-id]").forEach((c) => c.addEventListener("click", (e) => {
        if (e.target.closest("[data-remove-history]")) return;
        const h = hist.find((x) => x.id === c.dataset.resumeId);
        if (h) global.NoctisPlayer.open({ ...h, startPosition: h.position });
      }));
    },

    async renderCategoryView(container, type) {
      this.stopHeroTimer();
      const cat = await this.getAllCatalog();
      const map = { movies: ["Filmes", "Catálogo cinematográfico"], series: ["Séries", "Temporadas e episódios"], animes: ["Animes", "Animações e séries"], mylist: ["Minha Lista", "Conteúdos salvos para assistir depois"] };
      let items = [];
      if (type === "mylist") {
        const ids = new Set((await global.NoctisStorage.getProfileFavorites()).map((f) => f.mediaId));
        items = cat.filter((c) => ids.has(c.id));
      } else if (type === "movies") items = cat.filter((c) => c.type === "movie");
      else if (type === "series") items = cat.filter((c) => c.type === "series");
      else items = cat.filter((c) => c.type === "anime" || (c.genres || []).includes("Animes"));
      const [t, sub] = map[type] || ["Catálogo", ""];
      container.innerHTML = `<section class="page-view"><div class="page-header"><div><h1 class="page-title">${t}</h1><p class="page-subtitle">${sub}</p></div><button id="btn-cat-add" class="btn btn-primary btn-sm">+ Adicionar Título</button></div>${items.length ? `<div class="catalog-grid">${items.map((i) => this.buildPosterCard(i)).join("")}</div>` : `<div class="empty-state"><h3>Nenhum título encontrado</h3><p>Adicione favoritos ou cadastre seus próprios filmes e séries.</p></div>`}</section>`;
      document.getElementById("btn-cat-add").addEventListener("click", () => this.openAddContentModal());
      this.bindCatalogInteractions(container);
    },

    buildEpPayload(series, season, ep) {
      return { mediaId: series.id, mediaType: series.type, title: series.title, subtitle: `T${season.seasonNumber} • E${ep.episodeNumber} — ${ep.title}`, poster: series.poster, banner: ep.thumbnail || series.banner, sourceUrl: ep.sourceUrl || series.sourceUrl, seasonNumber: season.seasonNumber, episodeNumber: ep.episodeNumber, episodeId: ep.id, introEndSec: ep.introEndSec || 0 };
    },

    async playCatalogItem(item, seasonNum = null, epIdx = null) {
      if (item.type === "movie") {
        return global.NoctisPlayer.open({ mediaId: item.id, mediaType: "movie", title: item.title, subtitle: `${item.year} • ${(item.genres||[]).join(", ")}`, poster: item.poster, banner: item.banner, sourceUrl: item.sourceUrl, introEndSec: item.introEndSec || 0 });
      }
      const seasons = item.seasons || [];
      if (!seasons.length) return global.NoctisApp.toast("Série sem episódios cadastrados.", "error");
      const season = seasonNum != null ? seasons.find((s) => s.seasonNumber === seasonNum) || seasons[0] : seasons[0];
      const eps = season.episodes || [], idx = epIdx != null ? epIdx : 0, ep = eps[idx];
      if (!ep) return;
      let nextEp = null;
      if (idx + 1 < eps.length) nextEp = this.buildEpPayload(item, season, eps[idx + 1]);
      else {
        const ns = seasons[seasons.findIndex((s) => s.seasonNumber === season.seasonNumber) + 1];
        if (ns && ns.episodes && ns.episodes[0]) nextEp = this.buildEpPayload(item, ns, ns.episodes[0]);
      }
      const payload = this.buildEpPayload(item, season, ep);
      payload.nextEpisodePayload = nextEp;
      global.NoctisPlayer.open(payload);
    },

    async openDetailModal(id) {
      const cat = await this.getAllCatalog(), item = cat.find((c) => c.id === id);
      if (!item) return;
      const isFav = await global.NoctisStorage.isFavorite(item.id);
      const hist = await global.NoctisStorage.getProfileHistory();
      const sim = cat.filter((c) => c.id !== item.id && (c.genres||[]).some((g) => (item.genres||[]).includes(g))).slice(0, 6);
      let activeS = item.seasons?.[0]?.seasonNumber || 1;

      const draw = () => {
        const sObj = (item.seasons || []).find((s) => s.seasonNumber === activeS);
        const epHtml = sObj ? `<div style="margin-top:22px;"><h3 style="margin:0 0 12px;">Temporadas e Episódios</h3><div class="season-pills">${item.seasons.map((s) => `<button class="season-pill ${s.seasonNumber===activeS?"active":""}" data-spick="${s.seasonNumber}">${esc(s.title||"Temporada "+s.seasonNumber)}</button>`).join("")}</div><div class="episode-list">${(sObj.episodes||[]).map((ep, idx) => { const eh = hist.find((h) => h.mediaId === item.id && h.episodeId === ep.id); return `<div class="episode-card" data-play-ep="${idx}"><div class="episode-thumb"><img src="${esc(ep.thumbnail||item.banner)}" loading="lazy" />${eh?.percent ? `<div class="continue-progress-bar"><div class="continue-progress-fill" style="width:${eh.percent}%"></div></div>` : ""}</div><div class="episode-info"><div class="episode-header"><div class="episode-name">${ep.episodeNumber}. ${esc(ep.title)}</div><div class="episode-dur">${esc(ep.duration||"")}</div></div><div class="episode-desc">${esc(ep.description||"")}</div></div></div>`; }).join("")}</div></div>` : "";
        global.NoctisApp.openModal(`
          <div class="detail-hero" style="background-image:url('${esc(item.banner||item.poster)}')"><button class="detail-close-btn" id="btn-close-modal">✕</button><div class="detail-hero-inner"><img class="detail-poster" src="${esc(item.poster)}" /><div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;"><span class="badge badge-gold">${esc(item.rating||"12+")}</span><span class="badge">${item.year}</span><span class="badge badge-accent">${esc(item.duration||"")}</span></div><h2 class="detail-title">${esc(item.title)}</h2><div style="font-size:12.5px;color:var(--text-secondary);">${esc((item.genres||[]).join(" • "))}</div></div></div></div>
          <div class="detail-body">
            <div class="detail-actions">
              <button id="btn-d-watch" class="btn btn-primary">▶ Assistir</button>
              <button id="btn-d-fav" class="btn btn-secondary">${isFav ? "✓ Na Minha Lista" : "+ Minha Lista"}</button>
              ${item.trailerUrl || item.trailerYoutubeKey ? `<button id="btn-d-trailer" class="btn btn-ghost">Trailer</button>` : ""}
              <button id="btn-d-local" class="btn btn-ghost">Vincular MKV/MP4</button>
            </div>
            <p class="detail-synopsis">${esc(item.synopsis)}</p>
            <div class="detail-credits"><div><div class="credit-label">Direção</div><div>${esc(item.director||"Não informado")}</div></div><div><div class="credit-label">Elenco</div><div>${esc((item.cast||[]).join(", ")||"Não informado")}</div></div></div>
            ${epHtml}
            ${sim.length ? `<div style="margin-top:24px;"><h3 style="margin:0 0 12px;">Recomendações semelhantes</h3><div class="media-carousel" style="padding:4px 0 8px;">${sim.map((s) => this.buildPosterCard(s)).join("")}</div></div>` : ""}
          </div>`);
        document.getElementById("btn-d-watch").addEventListener("click", () => { global.NoctisApp.closeModal(); this.playCatalogItem(item, activeS, 0); });
        document.getElementById("btn-d-fav").addEventListener("click", async () => { const added = await global.NoctisStorage.toggleFavorite(item.id); global.NoctisApp.toast(added ? "Adicionado à Minha Lista!" : "Removido da Minha Lista."); this.openDetailModal(item.id); global.NoctisNav.refreshCurrentView(); });
        document.getElementById("btn-d-trailer")?.addEventListener("click", () => {
          if (item.trailerUrl) { global.NoctisApp.closeModal(); global.NoctisPlayer.open({ mediaId: `${item.id}-tr`, mediaType: "trailer", title: `${item.title} (Trailer)`, sourceUrl: item.trailerUrl }); }
          else if (item.trailerYoutubeKey) window.open(`https://www.youtube.com/watch?v=${item.trailerYoutubeKey}`, "_blank", "noopener");
        });
        document.getElementById("btn-d-local").addEventListener("click", async () => {
          const files = await global.NoctisNative.pickLocalVideos();
          if (!files.length) return;
          item.sourceUrl = files[0].uri; item.format = extOf(files[0].name);
          if (item.seasons?.[0]?.episodes?.[0]) item.seasons[0].episodes[0].sourceUrl = files[0].uri;
          await global.NoctisStorage.put("catalog", item);
          global.NoctisApp.toast(`Arquivo "${files[0].name}" vinculado!`, "success");
          this.openDetailModal(item.id);
        });
        document.querySelectorAll("[data-spick]").forEach((b) => b.addEventListener("click", () => { activeS = parseInt(b.dataset.spick, 10); draw(); }));
        document.querySelectorAll("[data-play-ep]").forEach((c) => c.addEventListener("click", () => { global.NoctisApp.closeModal(); this.playCatalogItem(item, activeS, parseInt(c.dataset.playEp, 10)); }));
        document.querySelectorAll(".modal-container [data-open-detail]").forEach((c) => c.addEventListener("click", () => this.openDetailModal(c.dataset.openDetail)));
      };
      draw();
    },

    openAddContentModal() {
      global.NoctisApp.openModal(`
        <div class="modal-header"><h3>Adicionar Filme ou Série</h3><button class="icon-btn" id="btn-close-modal">✕</button></div>
        <div class="modal-body">
          <div class="settings-card" style="margin-bottom:16px;padding:14px;">
            <div style="font-size:13px;font-weight:700;margin-bottom:8px;">Buscar Metadados no TMDB (Opcional)</div>
            <div style="display:flex;gap:8px;"><input id="tmdb-q" class="form-input" placeholder="Nome do filme ou série..." /><button id="btn-tmdb-go" class="btn btn-secondary btn-sm">Buscar</button></div>
            <div id="tmdb-res" style="margin-top:10px;display:flex;flex-direction:column;gap:8px;"></div>
          </div>
          <form id="add-media-form" class="form-grid two-col">
            <div class="form-group"><label>Título</label><input id="am-title" class="form-input" required /></div>
            <div class="form-group"><label>Tipo</label><select id="am-type" class="form-select"><option value="movie">Filme</option><option value="series">Série</option><option value="anime">Anime</option></select></div>
            <div class="form-group"><label>Ano</label><input id="am-year" class="form-input" type="number" value="2025" /></div>
            <div class="form-group"><label>Duração / Temporadas</label><input id="am-dur" class="form-input" value="110 min" /></div>
            <div class="form-group"><label>Gênero</label><select id="am-genre" class="form-select"><option>Ação</option><option>Ficção científica</option><option>Drama</option><option>Comédia</option><option>Terror</option><option>Documentários</option><option>Animes</option></select></div>
            <div class="form-group"><label>Diretor</label><input id="am-dir" class="form-input" /></div>
            <div class="form-group" style="grid-column:1/-1;"><label>Elenco</label><input id="am-cast" class="form-input" placeholder="Separado por vírgula" /></div>
            <div class="form-group" style="grid-column:1/-1;"><label>Sinopse</label><textarea id="am-syn" class="form-textarea"></textarea></div>
            <div class="form-group" style="grid-column:1/-1;"><label>Fonte (URL autorizada ou Arquivo Local MKV/MP4)</label><div style="display:flex;gap:8px;"><input id="am-src" class="form-input" /><button type="button" id="btn-am-local" class="btn btn-secondary btn-sm">Arquivo Local</button></div></div>
            <input type="hidden" id="am-poster" value="assets/images/posters/charge.svg" /><input type="hidden" id="am-banner" value="assets/images/banners/charge.svg" />
            <div style="grid-column:1/-1;display:flex;justify-content:flex-end;"><button type="submit" class="btn btn-primary">Salvar no Catálogo</button></div>
          </form>
        </div>`);
      document.getElementById("btn-am-local").addEventListener("click", async () => {
        const f = await global.NoctisNative.pickLocalVideos();
        if (f.length) { document.getElementById("am-src").value = f[0].uri; if (!document.getElementById("am-title").value) document.getElementById("am-title").value = f[0].name.replace(/\.[^/.]+$/, ""); }
      });
      document.getElementById("btn-tmdb-go").addEventListener("click", async () => {
        const box = document.getElementById("tmdb-res"), q = document.getElementById("tmdb-q").value.trim();
        if (!q) return;
        try {
          const list = await global.NoctisAPI.searchTMDB(q);
          box.innerHTML = list.slice(0, 4).map((r) => `<button type="button" class="episode-card tmdb-pick" data-tid="${r.tmdbId}" data-tt="${r.type}" style="width:100%;text-align:left;"><img src="${esc(r.poster)}" style="width:40px;height:60px;object-fit:cover;border-radius:6px;" /><div><b>${esc(r.title)}</b> (${r.year})</div></button>`).join("") || "Sem resultados.";
          box.querySelectorAll(".tmdb-pick").forEach((b) => b.addEventListener("click", async () => {
            const d = await global.NoctisAPI.fetchTMDBDetails(b.dataset.tid, b.dataset.tt);
            document.getElementById("am-title").value = d.title; document.getElementById("am-type").value = d.type; document.getElementById("am-year").value = d.year; document.getElementById("am-dur").value = d.duration; document.getElementById("am-dir").value = d.director; document.getElementById("am-cast").value = d.cast.join(", "); document.getElementById("am-syn").value = d.synopsis; document.getElementById("am-poster").value = d.poster; document.getElementById("am-banner").value = d.banner;
            global.NoctisApp.toast("Metadados preenchidos!", "success");
          }));
        } catch (err) { box.innerHTML = `<span style="color:#FDA4AF;font-size:12px;">${esc(err.message)}</span>`; }
      });
      document.getElementById("add-media-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const type = document.getElementById("am-type").value, genre = document.getElementById("am-genre").value, src = document.getElementById("am-src").value.trim(), id = `custom-${Date.now()}`;
        const item = { id, type, title: document.getElementById("am-title").value.trim(), year: parseInt(document.getElementById("am-year").value, 10)||2025, rating: "12+", duration: document.getElementById("am-dur").value.trim(), genres: [genre], categories: ["Lançamentos", type === "movie" ? "Filmes populares" : "Séries populares", genre], director: document.getElementById("am-dir").value.trim() || "Não informado", cast: document.getElementById("am-cast").value.split(",").map((x)=>x.trim()).filter(Boolean), synopsis: document.getElementById("am-syn").value.trim() || "Conteúdo adicionado ao Noctis.", poster: document.getElementById("am-poster").value, banner: document.getElementById("am-banner").value, sourceUrl: src, format: src ? extOf(src) : "LOCAL" };
        if (type !== "movie") item.seasons = [{ seasonNumber: 1, title: "Temporada 1", episodes: [{ id: `${id}-s1e1`, episodeNumber: 1, title: "Episódio 1", duration: item.duration, description: item.synopsis, thumbnail: item.banner, sourceUrl: src }] }];
        await global.NoctisStorage.put("catalog", item);
        global.NoctisApp.closeModal(); global.NoctisApp.toast("Salvo no catálogo!", "success"); global.NoctisNav.refreshCurrentView();
      });
    },

    async renderLocalVideosView(container) {
      this.stopHeroTimer();
      const videos = await global.NoctisStorage.getAll("localVideos");
      const favIds = new Set((await global.NoctisStorage.getProfileFavorites()).map((f) => f.mediaId));
      const playlists = await global.NoctisStorage.getProfilePlaylists();
      container.innerHTML = `
        <section class="page-view no-subtabs">
          <div class="page-header"><div><h1 class="page-title">Meus Vídeos</h1><p class="page-subtitle">Importe MKV, MP4, WebM, MOV e AVI do celular sem copiar arquivos grandes.</p></div><div style="display:flex;gap:10px;flex-wrap:wrap;"><button id="btn-imp-local" class="btn btn-primary">+ Selecionar Vídeos (MKV / MP4)</button><button id="btn-new-pl" class="btn btn-secondary">Nova Playlist</button></div></div>
          <div class="local-banner"><div><div style="font-weight:800;">Suporte Prioritário a MKV via Media3 / ExoPlayer</div><div style="font-size:12.5px;color:var(--text-secondary);">Seletor nativo Android (SAF), acesso direto por URI persistente, múltiplos áudios e legendas.</div></div><span class="badge badge-mkv">MKV • MP4 • WEBM • MOV • AVI</span></div>
          ${playlists.length ? `<div class="chip-list">${playlists.map((p) => `<span class="chip">🎬 ${esc(p.name)} (${(p.videoIds||[]).length})</span>`).join("")}</div>` : ""}
          ${videos.length ? `<div class="local-video-list">${videos.map((v) => `<article class="local-video-card"><div class="local-video-thumb" data-play-local="${v.id}"><img src="${esc(v.thumbnail||"assets/images/banners/charge.svg")}" loading="lazy" /><div class="continue-play-overlay"><div class="continue-play-circle">▶</div></div><div class="poster-top-badges"><span class="badge badge-mkv">${extOf(v.name)}</span><span class="badge">${fmtMs(v.durationMs)}</span></div></div><div class="local-video-body"><div class="local-video-name">${esc(v.name)}</div><div class="local-video-actions"><button class="btn btn-primary btn-sm" data-play-local="${v.id}">▶ Assistir</button><button class="btn btn-secondary btn-sm" data-fav-local="${v.id}">${favIds.has(v.id) ? "★ Favorito" : "☆ Favoritar"}</button><button class="btn btn-danger btn-sm" data-del-local="${v.id}">Excluir</button></div></div></article>`).join("")}</div>` : `<div class="empty-state"><h3>Nenhum vídeo local importado</h3><p>Toque em "Selecionar Vídeos" para abrir arquivos MKV ou MP4 do seu Android.</p></div>`}
        </section>`;
      document.getElementById("btn-imp-local").addEventListener("click", async () => {
        const picked = await global.NoctisNative.pickLocalVideos();
        if (!picked.length) return;
        for (const f of picked) await global.NoctisStorage.put("localVideos", { id: `local-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, uri: f.uri, name: f.name || "Vídeo Local", mimeType: f.mimeType || "video/*", durationMs: f.durationMs || 0, thumbnail: f.thumbnail || "assets/images/banners/charge.svg", addedAt: Date.now() });
        global.NoctisApp.toast(`${picked.length} vídeo(s) importado(s)!`, "success");
        this.renderLocalVideosView(container);
      });
      document.getElementById("btn-new-pl").addEventListener("click", async () => {
        const n = prompt("Nome da playlist:");
        if (n && n.trim()) { await global.NoctisStorage.savePlaylist({ name: n.trim(), videoIds: videos.map((v) => v.id) }); this.renderLocalVideosView(container); }
      });
      container.querySelectorAll("[data-play-local]").forEach((el) => el.addEventListener("click", () => {
        const v = videos.find((x) => x.id === el.dataset.playLocal);
        if (v) global.NoctisPlayer.open({ mediaId: v.id, mediaType: "local", title: v.name, subtitle: `Arquivo Local • ${extOf(v.name)}`, poster: v.thumbnail, banner: v.thumbnail, sourceUrl: v.uri, isLocal: true });
      }));
      container.querySelectorAll("[data-fav-local]").forEach((b) => b.addEventListener("click", async () => { await global.NoctisStorage.toggleFavorite(b.dataset.favLocal, "local"); this.renderLocalVideosView(container); }));
      container.querySelectorAll("[data-del-local]").forEach((b) => b.addEventListener("click", async () => { await global.NoctisStorage.delete("localVideos", b.dataset.delLocal); this.renderLocalVideosView(container); }));
    }
  };
})(window);
