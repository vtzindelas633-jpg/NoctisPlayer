(function (global) {
  const DB_NAME = "NoctisStreamingDB";
  const DB_VERSION = 2;
  const STORES = ["profiles", "catalog", "localVideos", "history", "favorites", "playlists", "searchHistory", "settings"];
  let dbInstance = null;

  function openDB() {
    if (dbInstance) return Promise.resolve(dbInstance);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        STORES.forEach((s) => { if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: "id" }); });
      };
      req.onsuccess = (e) => { dbInstance = e.target.result; resolve(dbInstance); };
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function tx(storeName, mode, op) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const r = op(db.transaction(storeName, mode).objectStore(storeName));
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }

  global.NoctisStorage = {
    async init() { await openDB(); },
    getAll(s) { return tx(s, "readonly", (st) => st.getAll()); },
    get(s, id) { return tx(s, "readonly", (st) => st.get(id)); },
    put(s, item) { return tx(s, "readwrite", (st) => st.put(item)); },
    delete(s, id) { return tx(s, "readwrite", (st) => st.delete(id)); },
    clearStore(s) { return tx(s, "readwrite", (st) => st.clear()); },
    async clearAllData() {
      for (const s of STORES) await this.clearStore(s);
      localStorage.removeItem("noctis_active_profile");
    },
    getActiveProfileId() { return localStorage.getItem("noctis_active_profile") || "profile-default"; },
    setActiveProfileId(id) { localStorage.setItem("noctis_active_profile", id); },
    async getProfileSettings(profileId) {
      const pid = profileId || this.getActiveProfileId();
      return (await this.get("settings", `settings_${pid}`)) || {
        id: `settings_${pid}`, profileId: pid, accent: "aurora", reducedMotion: false,
        preferredQuality: "auto", defaultSpeed: 1.0, autoPlayNext: true,
        preferredAudio: "pt", preferredSubtitle: "pt", preferNativePlayer: true, tmdbApiKey: ""
      };
    },
    async saveProfileSettings(obj) {
      const pid = obj.profileId || this.getActiveProfileId();
      obj.id = `settings_${pid}`; obj.profileId = pid;
      await this.put("settings", obj);
      return obj;
    },
    async saveWatchProgress(entry) {
      const pid = this.getActiveProfileId();
      const key = `${pid}__${entry.mediaId}${entry.episodeId ? "__" + entry.episodeId : ""}`;
      const dur = Math.max(0, Number(entry.duration) || 0);
      const pos = Math.max(0, Number(entry.position) || 0);
      const rec = {
        id: key, profileId: pid, mediaId: entry.mediaId, mediaType: entry.mediaType || "movie",
        title: entry.title, subtitle: entry.subtitle || "", poster: entry.poster || "", banner: entry.banner || "",
        sourceUrl: entry.sourceUrl || "", isLocal: !!entry.isLocal,
        seasonNumber: entry.seasonNumber || null, episodeNumber: entry.episodeNumber || null, episodeId: entry.episodeId || null,
        position: pos, duration: dur, percent: dur > 0 ? Math.min(100, Math.round((pos / dur) * 100)) : 0, updatedAt: Date.now()
      };
      await this.put("history", rec);
      return rec;
    },
    async getProfileHistory(profileId) {
      const pid = profileId || this.getActiveProfileId();
      return (await this.getAll("history")).filter((h) => h.profileId === pid).sort((a, b) => b.updatedAt - a.updatedAt);
    },
    async getMediaProgress(mediaId, episodeId = null) {
      const pid = this.getActiveProfileId();
      return this.get("history", `${pid}__${mediaId}${episodeId ? "__" + episodeId : ""}`);
    },
    async removeHistoryItem(id) { return this.delete("history", id); },
    async clearProfileHistory(profileId) {
      for (const item of await this.getProfileHistory(profileId)) await this.delete("history", item.id);
    },
    async toggleFavorite(mediaId, mediaKind = "catalog") {
      const pid = this.getActiveProfileId();
      const key = `${pid}__${mediaId}`;
      if (await this.get("favorites", key)) { await this.delete("favorites", key); return false; }
      await this.put("favorites", { id: key, profileId: pid, mediaId, mediaKind, addedAt: Date.now() });
      return true;
    },
    async isFavorite(mediaId) { return !!(await this.get("favorites", `${this.getActiveProfileId()}__${mediaId}`)); },
    async getProfileFavorites(profileId) {
      const pid = profileId || this.getActiveProfileId();
      return (await this.getAll("favorites")).filter((f) => f.profileId === pid).sort((a, b) => b.addedAt - a.addedAt);
    },
    async getProfilePlaylists(profileId) {
      const pid = profileId || this.getActiveProfileId();
      return (await this.getAll("playlists")).filter((p) => p.profileId === pid);
    },
    async savePlaylist(pl) {
      pl.profileId = this.getActiveProfileId();
      if (!pl.id) pl.id = `pl_${Date.now()}`;
      await this.put("playlists", pl);
      return pl;
    },
    async addSearchTerm(term) {
      const clean = (term || "").trim();
      if (!clean) return;
      const pid = this.getActiveProfileId();
      await this.put("searchHistory", { id: `${pid}__${clean.toLowerCase()}`, profileId: pid, term: clean, searchedAt: Date.now() });
    },
    async getSearchHistory() {
      const pid = this.getActiveProfileId();
      return (await this.getAll("searchHistory")).filter((s) => s.profileId === pid).sort((a, b) => b.searchedAt - a.searchedAt).slice(0, 12);
    },
    async clearSearchHistory() {
      for (const item of await this.getSearchHistory()) await this.delete("searchHistory", item.id);
    }
  };
})(window);
