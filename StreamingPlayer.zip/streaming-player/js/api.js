(function (global) {
  const TMDB_BASE = "https://api.themoviedb.org/3";
  const IMG_P = "https://image.tmdb.org/t/p/w500";
  const IMG_B = "https://image.tmdb.org/t/p/w1280";

  async function getApiKey() {
    const s = await global.NoctisStorage.getProfileSettings();
    return ((s && s.tmdbApiKey) || "").trim();
  }

  async function req(endpoint, params = {}) {
    const key = await getApiKey();
    if (!key) throw new Error("Chave TMDB não configurada. Acesse Configurações para informar sua chave.");
    const url = new URL(`${TMDB_BASE}${endpoint}`);
    url.searchParams.set("api_key", key);
    url.searchParams.set("language", "pt-BR");
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
    const res = await fetch(url.toString());
    if (!res.ok) throw new Error(`TMDB HTTP ${res.status}`);
    return res.json();
  }

  global.NoctisAPI = {
    async isConfigured() { return !!(await getApiKey()); },
    async searchTMDB(query, type = "multi") {
      const ep = type === "movie" ? "/search/movie" : type === "tv" ? "/search/tv" : "/search/multi";
      const data = await req(ep, { query, include_adult: "false" });
      return (data.results || []).filter((i) => i.media_type !== "person").map((i) => {
        const isTv = type === "tv" || i.media_type === "tv";
        return {
          tmdbId: i.id, type: isTv ? "series" : "movie", title: i.title || i.name || "Sem título",
          year: Number((i.release_date || i.first_air_date || "2025").slice(0, 4)) || 2025,
          synopsis: i.overview || "Sinopse indisponível.",
          poster: i.poster_path ? `${IMG_P}${i.poster_path}` : "assets/images/posters/meridian.jpg",
          banner: i.backdrop_path ? `${IMG_B}${i.backdrop_path}` : "assets/images/banners/meridian.jpg"
        };
      });
    },
    async fetchTMDBDetails(tmdbId, type = "movie") {
      const d = await req(type === "series" ? `/tv/${tmdbId}` : `/movie/${tmdbId}`, { append_to_response: "credits,videos" });
      const genres = (d.genres || []).map((g) => g.name);
      const cast = ((d.credits && d.credits.cast) || []).slice(0, 6).map((c) => c.name);
      const dirObj = ((d.credits && d.credits.crew) || []).find((c) => c.job === "Director");
      const trailer = ((d.videos && d.videos.results) || []).find((v) => v.site === "YouTube" && v.type === "Trailer");
      return {
        id: `tmdb-${type}-${tmdbId}`, tmdbId, type: type === "series" ? "series" : "movie",
        title: d.title || d.name, year: Number((d.release_date || d.first_air_date || "2025").slice(0, 4)) || 2025,
        rating: d.adult ? "18+" : "14+",
        duration: type === "series" ? `${d.number_of_seasons || 1} Temporada(s)` : `${d.runtime || 100} min`,
        genres: genres.length ? genres : ["Drama"],
        categories: [type === "series" ? "Séries populares" : "Filmes populares", ...genres],
        poster: d.poster_path ? `${IMG_P}${d.poster_path}` : "assets/images/posters/meridian.jpg",
        banner: d.backdrop_path ? `${IMG_B}${d.backdrop_path}` : "assets/images/banners/meridian.jpg",
        synopsis: d.overview || "Sinopse indisponível.",
        director: dirObj ? dirObj.name : "Não informado", cast,
        trailerYoutubeKey: trailer ? trailer.key : "", sourceUrl: "", seasons: []
      };
    }
  };
})(window);
