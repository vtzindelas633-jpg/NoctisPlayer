(function (global) {
  const ACCENTS = [
    { id: "aurora", color: "#7C5CFF" }, { id: "gold", color: "#F5B74F" },
    { id: "crimson", color: "#E11D48" }, { id: "emerald", color: "#10B981" }, { id: "arctic", color: "#38BDF8" }
  ];
  global.NoctisSettings = {
    async applySavedAppearance() {
      const s = await global.NoctisStorage.getProfileSettings();
      document.documentElement.setAttribute("data-accent", s.accent || "aurora");
      document.body.classList.toggle("reduced-motion", !!s.reducedMotion);
    },
    async render(container) {
      global.NoctisCatalog.stopHeroTimer();
      const s = await global.NoctisStorage.getProfileSettings();
      const tech = await global.NoctisNative.getTechnicalInfo();
      container.innerHTML = `
        <section class="page-view no-subtabs">
          <div class="page-header"><div><h1 class="page-title">Configurações</h1><p class="page-subtitle">Aparência, reprodução MKV, TMDB e dados locais.</p></div></div>
          <div class="settings-sections">
            <div class="settings-card"><h3>Aparência</h3>
              <div class="setting-row"><div><div class="setting-label">Cor de destaque</div></div><div class="accent-swatches">${ACCENTS.map((a) => `<button class="swatch ${s.accent===a.id?"active":""}" style="background:${a.color}" data-acc="${a.id}"></button>`).join("")}</div></div>
              <div class="setting-row"><div><div class="setting-label">Reduzir animações</div></div><input id="s-rm" type="checkbox" ${s.reducedMotion?"checked":""} /></div>
            </div>
            <div class="settings-card"><h3>Reprodução &amp; MKV</h3>
              <div class="setting-row"><div><div class="setting-label">Priorizar Player Nativo Media3/ExoPlayer</div><div class="setting-desc">Essencial para MKV, múltiplas faixas de áudio e legendas no Android.</div></div><input id="s-nat" type="checkbox" ${s.preferNativePlayer!==false?"checked":""} /></div>
              <div class="setting-row"><div class="setting-label">Qualidade preferida</div><select id="s-qual" class="form-select" style="width:auto;"><option value="auto" ${s.preferredQuality==="auto"?"selected":""}>Automática</option><option value="1080p" ${s.preferredQuality==="1080p"?"selected":""}>1080p</option><option value="720p" ${s.preferredQuality==="720p"?"selected":""}>720p</option></select></div>
              <div class="setting-row"><div class="setting-label">Velocidade padrão</div><select id="s-spd" class="form-select" style="width:auto;">${[0.75,1.0,1.25,1.5,2.0].map((v)=>`<option value="${v}" ${Number(s.defaultSpeed)===v?"selected":""}>${v}x</option>`).join("")}</select></div>
              <div class="setting-row"><div class="setting-label">Reprodução automática próximo episódio</div><input id="s-auto" type="checkbox" ${s.autoPlayNext!==false?"checked":""} /></div>
              <div class="setting-row"><div class="setting-label">Áudio / Legenda preferidos</div><div style="display:flex;gap:8px;"><select id="s-aud" class="form-select" style="width:auto;"><option value="pt" ${s.preferredAudio==="pt"?"selected":""}>PT</option><option value="en" ${s.preferredAudio==="en"?"selected":""}>EN</option><option value="ja" ${s.preferredAudio==="ja"?"selected":""}>JA</option></select><select id="s-sub" class="form-select" style="width:auto;"><option value="pt" ${s.preferredSubtitle==="pt"?"selected":""}>Leg. PT</option><option value="en" ${s.preferredSubtitle==="en"?"selected":""}>Leg. EN</option><option value="off" ${s.preferredSubtitle==="off"?"selected":""}>Off</option></select></div></div>
            </div>
            <div class="settings-card"><h3>API TMDB (Opcional)</h3>
              <div style="display:flex;gap:8px;"><input id="s-tmdb" class="form-input" type="password" placeholder="Chave TMDB v3 (salva localmente)" value="${s.tmdbApiKey||""}" /><button id="btn-save-tmdb" class="btn btn-primary btn-sm">Salvar</button></div>
            </div>
            <div class="settings-card"><h3>Biblioteca</h3>
              <div style="display:flex;flex-wrap:wrap;gap:10px;"><button id="btn-ch" class="btn btn-secondary btn-sm">Limpar Histórico</button><button id="btn-mp" class="btn btn-secondary btn-sm">Perfis</button><button id="btn-ml" class="btn btn-secondary btn-sm">Meus Vídeos</button><button id="btn-wa" class="btn btn-danger btn-sm">Limpar Todos os Dados</button></div>
            </div>
            <div class="settings-card"><h3>Sobre o Noctis</h3>
              <div class="setting-row"><div class="setting-label">Versão</div><span class="badge badge-accent">Noctis v1.0.0 (Android 8+)</span></div>
              <div class="setting-row"><div class="setting-label">Motor</div><div style="font-size:12px;color:var(--text-secondary);text-align:right;">${tech.platform}<br/>${tech.engine}</div></div>
              <div class="setting-row"><div class="setting-desc">Política de Privacidade: dados e biblioteca local permanecem exclusivamente no dispositivo.</div></div>
            </div>
          </div>
        </section>`;
      const save = async () => {
        s.reducedMotion = document.getElementById("s-rm").checked; s.preferNativePlayer = document.getElementById("s-nat").checked;
        s.preferredQuality = document.getElementById("s-qual").value; s.defaultSpeed = parseFloat(document.getElementById("s-spd").value);
        s.autoPlayNext = document.getElementById("s-auto").checked; s.preferredAudio = document.getElementById("s-aud").value; s.preferredSubtitle = document.getElementById("s-sub").value;
        await global.NoctisStorage.saveProfileSettings(s); await this.applySavedAppearance(); global.NoctisApp.toast("Salvo!", "success");
      };
      container.querySelectorAll("[data-acc]").forEach((b) => b.addEventListener("click", async () => { s.accent = b.dataset.acc; await global.NoctisStorage.saveProfileSettings(s); await this.applySavedAppearance(); this.render(container); }));
      ["s-rm","s-nat","s-qual","s-spd","s-auto","s-aud","s-sub"].forEach((id) => document.getElementById(id).addEventListener("change", save));
      document.getElementById("btn-save-tmdb").addEventListener("click", async () => { s.tmdbApiKey = document.getElementById("s-tmdb").value.trim(); await global.NoctisStorage.saveProfileSettings(s); global.NoctisApp.toast("Chave TMDB atualizada!", "success"); });
      document.getElementById("btn-ch").addEventListener("click", async () => { await global.NoctisStorage.clearProfileHistory(); global.NoctisApp.toast("Histórico limpo."); });
      document.getElementById("btn-mp").addEventListener("click", () => global.NoctisNav.go("profile"));
      document.getElementById("btn-ml").addEventListener("click", () => global.NoctisNav.go("local"));
      document.getElementById("btn-wa").addEventListener("click", async () => { if (confirm("Apagar todos os dados locais?")) { await global.NoctisStorage.clearAllData(); location.reload(); } });
    }
  };
})(window);
